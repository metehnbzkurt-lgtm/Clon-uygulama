# Ek kural gerekmiyor; manifest bilesenleri otomatik korunur.

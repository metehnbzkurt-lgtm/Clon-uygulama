package com.oguzhn.klonlayici

import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager

class AdminReceiver : DeviceAdminReceiver() {

    override fun onProfileProvisioningComplete(context: Context, intent: Intent) {
        val dpm = context.getSystemService(DevicePolicyManager::class.java)
        val admin = ComponentName(context, AdminReceiver::class.java)

        dpm.setProfileName(admin, "Klon Alanı")

        // Ana taraf, klon alanındaki CloneActivity'ye istek gönderebilsin
        val filter = IntentFilter(ProfileHelper.ACTION_CLONE).apply {
            addCategory(Intent.CATEGORY_DEFAULT)
        }
        dpm.addCrossProfileIntentFilter(admin, filter, DevicePolicyManager.FLAG_PARENT_CAN_ACCESS_MANAGED)

        // CloneActivity yalnızca profilde aktif olur
        context.packageManager.setComponentEnabledSetting(
            ComponentName(context, CloneActivity::class.java),
            PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
            PackageManager.DONT_KILL_APP
        )

        dpm.setProfileEnabled(admin)
    }
}

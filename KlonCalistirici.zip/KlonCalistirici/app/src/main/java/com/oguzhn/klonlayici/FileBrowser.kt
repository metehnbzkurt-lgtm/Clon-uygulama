package com.oguzhn.klonlayici

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class FileEntry(
    val file: File,
    val isDir: Boolean,
    val name: String,
    val size: Long,
    val modified: Long
) {
    val isApk: Boolean get() = !isDir && name.endsWith(".apk", ignoreCase = true)
    val ext: String get() = name.substringAfterLast('.', "").take(4).uppercase(Locale("tr", "TR")).ifEmpty { "?" }
}

data class ApkInfo(val label: String, val pkg: String, val version: String, val icon: ImageBitmap?)

object Files {
    private val TR = Locale("tr", "TR")

    fun root(): File = Environment.getExternalStorageDirectory()

    fun hasAccess(ctx: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else ctx.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    fun quick(): List<Pair<String, File>> = listOf(
        "Dahili" to root(),
        "İndirilenler" to Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
        "Kamera" to Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM),
        "Belgeler" to Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
    )

    fun list(dir: File, apkOnly: Boolean, hidden: Boolean): List<FileEntry> {
        val arr = runCatching { dir.listFiles() }.getOrNull() ?: return emptyList()
        return arr.asSequence()
            .filter { hidden || !it.name.startsWith(".") }
            .map { FileEntry(it, it.isDirectory, it.name, if (it.isFile) it.length() else 0L, it.lastModified()) }
            .filter { !apkOnly || it.isDir || it.isApk }
            .sortedWith(compareByDescending<FileEntry> { it.isDir }.thenBy { it.name.lowercase(TR) })
            .toList()
    }

    fun formatSize(b: Long): String {
        if (b < 1024) return "$b B"
        val units = arrayOf("KB", "MB", "GB", "TB")
        var v = b.toDouble()
        var i = -1
        while (v >= 1024 && i < units.lastIndex) { v /= 1024; i++ }
        return String.format(TR, "%.1f %s", v, units[i])
    }

    fun formatDate(ms: Long): String = SimpleDateFormat("d MMM yyyy", TR).format(Date(ms))

    /** APK dosyasının adını, paket adını, sürümünü ve simgesini okur. */
    fun readApk(ctx: Context, f: File): ApkInfo? = runCatching {
        val pm = ctx.packageManager
        val pi = pm.getPackageArchiveInfo(f.path, 0) ?: return@runCatching null
        val ai = pi.applicationInfo ?: return@runCatching null
        ai.sourceDir = f.path
        ai.publicSourceDir = f.path
        ApkInfo(
            label = ai.loadLabel(pm).toString(),
            pkg = pi.packageName,
            version = pi.versionName ?: "",
            icon = runCatching { ai.loadIcon(pm).toBitmap(96, 96).asImageBitmap() }.getOrNull()
        )
    }.getOrNull()
}

package com.oguzhn.klonlayici

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { KlonTheme { Root() } }
    }
}

@Composable
fun KlonTheme(content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val dark = isSystemInDarkTheme()
    val scheme = when {
        Build.VERSION.SDK_INT >= 31 ->
            if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun Root() {
    val ctx = LocalContext.current
    val inside = remember { ProfileHelper.isInsideProfile(ctx) }
    var tick by remember { mutableIntStateOf(0) }

    // Ekrana her dönüşte durumu yenile
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    if (inside) InsideScreen() else PersonalScreen(tick) { tick++ }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InsideScreen() {
    Scaffold(topBar = { TopAppBar(title = { Text("Klon Alanı") }) }) { pad ->
        Column(
            Modifier.padding(pad).padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Klon alanı hazır", style = MaterialTheme.typography.headlineSmall)
            Text(
                "Uygulama seçmek için ana taraftaki Klon Çalıştırıcı'yı aç. " +
                    "Klonlanan uygulamalar buradaki rozetli simgelerle çalışır.",
                style = MaterialTheme.typography.bodyLarge
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PersonalScreen(tick: Int, refresh: () -> Unit) {
    val ctx = LocalContext.current
    val profile = remember(tick) { ProfileHelper.findProfile(ctx) }
    var tab by remember { mutableIntStateOf(0) }

    val setup = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { refresh() }

    Scaffold(
        topBar = { LargeTopAppBar(title = { Text("Klon Çalıştırıcı") }) },
        bottomBar = {
            if (profile != null) NavigationBar {
                NavigationBarItem(
                    selected = tab == 0, onClick = { tab = 0 },
                    icon = { Icon(Icons.Filled.Home, null) }, label = { Text("Klonlarım") }
                )
                NavigationBarItem(
                    selected = tab == 1, onClick = { tab = 1 },
                    icon = { Icon(Icons.Filled.Add, null) }, label = { Text("Klonla") }
                )
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (profile == null) {
                SetupCard {
                    val i = Intent(DevicePolicyManager.ACTION_PROVISION_MANAGED_PROFILE)
                        .putExtra(
                            DevicePolicyManager.EXTRA_PROVISIONING_DEVICE_ADMIN_COMPONENT_NAME,
                            ComponentName(ctx, AdminReceiver::class.java)
                        )
                    runCatching { setup.launch(i) }.onFailure {
                        Toast.makeText(ctx, "Bu cihazda klon alanı kurulamadı", Toast.LENGTH_LONG).show()
                    }
                }
            } else {
                val clones = remember(tick) { ProfileHelper.cloneApps(ctx, profile) }
                if (tab == 0) {
                    AppList(
                        apps = clones,
                        empty = "Henüz klon yok. \"Klonla\" sekmesinden bir uygulama seç.",
                        action = { app ->
                            if (!ProfileHelper.launch(ctx, app, profile))
                                Toast.makeText(ctx, "Ana ekrandaki rozetli simgeden aç", Toast.LENGTH_LONG).show()
                        },
                        actionLabel = "Aç"
                    )
                } else {
                    val apps = remember(tick) {
                        ProfileHelper.personalApps(ctx, clones.map { it.pkg }.toSet())
                    }
                    AppList(
                        apps = apps,
                        empty = "Uygulama bulunamadı",
                        action = { app -> ProfileHelper.requestClone(ctx, app.pkg) },
                        actionLabel = "Klonla"
                    )
                }
            }
        }
    }
}

@Composable
fun SetupCard(onSetup: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        ElevatedCard(shape = RoundedCornerShape(28.dp)) {
            Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Klon alanını kur", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
                Text(
                    "Android'in resmi çalışma profili özelliği kullanılır. " +
                        "Seçtiğin uygulamalar bu ayrı alanda ikinci kopya olarak çalışır; " +
                        "verileri ana uygulamayla karışmaz.",
                    style = MaterialTheme.typography.bodyMedium
                )
                Button(onClick = onSetup, modifier = Modifier.fillMaxWidth()) { Text("Kurulumu başlat") }
            }
        }
    }
}

@Composable
fun AppList(apps: List<AppItem>, empty: String, action: (AppItem) -> Unit, actionLabel: String) {
    if (apps.isEmpty()) {
        Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Text(empty, style = MaterialTheme.typography.bodyLarge)
        }
        return
    }
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(apps, key = { it.pkg }) { app ->
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    val bmp = remember(app.pkg) { app.icon.toBitmap(96, 96).asImageBitmap() }
                    Image(bmp, null, Modifier.size(48.dp))
                    Column(Modifier.weight(1f)) {
                        Text(app.label, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                        Text(
                            app.pkg, style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1
                        )
                    }
                    if (app.cloned && actionLabel == "Klonla") {
                        Icon(Icons.Filled.Check, "Klonlandı", tint = MaterialTheme.colorScheme.primary)
                    } else {
                        FilledTonalButton(onClick = { action(app) }) { Text(actionLabel) }
                    }
                }
            }
        }
    }
}

package com.oguzhn.klonlayici

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color as AColor
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Kalıcı ayarlar (tema, dinamik renk, sistem uygulamaları) */
class AppSettings(ctx: Context) {
    private val sp = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var theme by mutableIntStateOf(sp.getInt("theme", 0))   // 0 sistem, 1 açık, 2 koyu
        private set
    var dynamic by mutableStateOf(sp.getBoolean("dynamic", true))
        private set
    var showSystem by mutableStateOf(sp.getBoolean("system", false))
        private set

    fun updateTheme(v: Int) { theme = v; sp.edit().putInt("theme", v).apply() }
    fun updateDynamic(v: Boolean) { dynamic = v; sp.edit().putBoolean("dynamic", v).apply() }
    fun updateShowSystem(v: Boolean) { showSystem = v; sp.edit().putBoolean("system", v).apply() }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val settings = AppSettings(applicationContext)
        setContent { KlonTheme(settings) { Root(settings) } }
    }
}

@Composable
fun KlonTheme(s: AppSettings, content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val dark = when (s.theme) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    val scheme = when {
        s.dynamic && Build.VERSION.SDK_INT >= 31 ->
            if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    val activity = ctx as? ComponentActivity
    SideEffect {
        val bars = if (dark) SystemBarStyle.dark(AColor.TRANSPARENT)
        else SystemBarStyle.light(AColor.TRANSPARENT, AColor.TRANSPARENT)
        activity?.enableEdgeToEdge(statusBarStyle = bars, navigationBarStyle = bars)
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun Root(settings: AppSettings) {
    val ctx = LocalContext.current
    val inside = remember { ProfileHelper.isInsideProfile(ctx) }
    // Profil tarafı her açılışta kendini onarır (klon filtresi / CloneActivity)
    if (inside) LaunchedEffect(Unit) {
        withContext(Dispatchers.Default) { ProfileHelper.setupProfileSide(ctx) }
        Toast.makeText(ctx, "Klon alanı hazır. Ana taraftaki uygulamadan devam edebilirsin.", Toast.LENGTH_LONG).show()
    }
    var tick by remember { mutableIntStateOf(0) }

    // Ekrana her dönüşte durumu yenile
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    if (inside) InsideScreen() else PersonalScreen(settings, tick) { tick++ }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InsideScreen() {
    val ctx = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) ApkInstaller.install(ctx, uri)
    }
    Scaffold(topBar = { TopAppBar(title = { Text("Klon Alanı") }) }) { pad ->
        Column(
            Modifier.padding(pad).padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Klon alanı hazır", style = MaterialTheme.typography.headlineSmall)
            Text(
                "Uygulama seçmek için ana taraftaki Klon Çalıştırıcı'yı aç. " +
                    "Klonlanan uygulamalar buradaki rozetli simgelerle çalışır.",
                style = MaterialTheme.typography.bodyLarge
            )
            Button(onClick = {
                picker.launch(arrayOf("application/vnd.android.package-archive", "application/octet-stream"))
            }) { Text("APK Yükle") }
            val blocked = remember {
                runCatching {
                    val b = ctx.getSystemService(android.os.UserManager::class.java).userRestrictions
                    b.keySet().filter { b.getBoolean(it) && (it.contains("install") || it.contains("unknown")) }
                }.getOrDefault(emptyList())
            }
            Text(
                if (blocked.isEmpty()) "Kurulum kısıtı: yok"
                else "Etkin kurulum kısıtları: " + blocked.joinToString(", "),
                style = MaterialTheme.typography.bodySmall
            )
            Text(
                "İlk kullanımda açılan ayarda Klon Çalıştırıcı için \"Bu kaynaktan izin ver\"i aç. " +
                    "İndirilen bir APK'ya dosya yöneticisinden dokunursan da buradan kurulur.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PersonalScreen(settings: AppSettings, tick: Int, refresh: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val profile = remember(tick) { ProfileHelper.findProfile(ctx) }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var query by rememberSaveable { mutableStateOf("") }

    // Ağır iş (uygulama listesi + simgeler) arka planda
    val loaded by produceState(Loaded(), profile, tick) {
        value = withContext(Dispatchers.Default) {
            ProfileHelper.load(ctx, profile, false)
        }
    }

    val setup = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        refresh()
        if (r.resultCode != Activity.RESULT_OK) {
            Toast.makeText(ctx, "Kurulum tamamlanmadı", Toast.LENGTH_SHORT).show()
        }
    }

    Scaffold(
        modifier = Modifier.imePadding(),
        topBar = { TopAppBar(title = { Text("Klon Çalıştırıcı", fontWeight = FontWeight.SemiBold) }) },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == 0, onClick = { tab = 0; query = "" },
                    icon = { Icon(Icons.Filled.Home, null) }, label = { Text("Klonlarım") }
                )
                NavigationBarItem(
                    selected = tab == 1, onClick = { tab = 1 },
                    icon = { Icon(Icons.Filled.Settings, null) }, label = { Text("Ayarlar") }
                )
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (tab == 1) {
                SettingsScreen(settings)
            } else if (profile == null) {
                SetupCard {
                    val i = Intent(DevicePolicyManager.ACTION_PROVISION_MANAGED_PROFILE)
                        .putExtra(
                            DevicePolicyManager.EXTRA_PROVISIONING_DEVICE_ADMIN_COMPONENT_NAME,
                            ComponentName(ctx, AdminReceiver::class.java)
                        )
                    runCatching { setup.launch(i) }.onFailure {
                        Toast.makeText(ctx, "Bu cihazda klon alanı kurulamadı", Toast.LENGTH_LONG).show()
                    }
                }
            } else {
                if (!loaded.ready) LinearProgressIndicator(Modifier.fillMaxWidth())
                SearchField(query) { query = it }

                val list = remember(loaded, query) { loaded.clones.filterQuery(query) }
                val emptyText = when {
                    !loaded.ready -> "Yükleniyor…"
                    loaded.clones.isEmpty() -> "Henüz uygulama yok. Klon alanındaki Play Store'dan uygulama indirebilirsin."
                    else -> "Sonuç bulunamadı"
                }

                AppList(
                    apps = list,
                    emptyText = emptyText,
                    modifier = Modifier.weight(1f),
                    onOpen = { app ->
                        if (!ProfileHelper.launch(ctx, app, profile)) {
                            Toast.makeText(ctx, "Ana ekrandaki rozetli simgeden aç", Toast.LENGTH_LONG).show()
                        }
                    },
                    onRemove = { app ->
                        if (ProfileHelper.requestRemove(ctx, app.pkg)) {
                            scope.launch { delay(2000); refresh(); delay(4000); refresh() }
                        } else {
                            ProfileHelper.openProfileSide(ctx, profile)
                            Toast.makeText(
                                ctx,
                                "Klon alanı onarılıyor. Açılan ekrandan geri dönüp tekrar dene.",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun SearchField(value: String, onChange: (String) -> Unit) {
    val focus = LocalFocusManager.current
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        placeholder = { Text("Uygulama ara") },
        leadingIcon = { Icon(Icons.Filled.Search, null) },
        trailingIcon = {
            if (value.isNotEmpty()) {
                IconButton(onClick = { onChange("") }) { Icon(Icons.Filled.Close, "Temizle") }
            }
        },
        singleLine = true,
        shape = RoundedCornerShape(28.dp),
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { focus.clearFocus() })
    )
}

@Composable
fun SetupCard(onSetup: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        ElevatedCard(shape = RoundedCornerShape(28.dp)) {
            Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Klon alanını kur", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
                Text(
                    "Android'in resmi çalışma profili özelliği kullanılır. " +
                        "Seçtiğin uygulamalar bu ayrı alanda ikinci kopya olarak çalışır; " +
                        "verileri ana uygulamayla karışmaz.",
                    style = MaterialTheme.typography.bodyMedium
                )
                Button(onClick = onSetup, modifier = Modifier.fillMaxWidth()) { Text("Kurulumu başlat") }
            }
        }
    }
}

@Composable
fun AppList(
    apps: List<AppItem>,
    emptyText: String,
    modifier: Modifier = Modifier,
    onOpen: (AppItem) -> Unit,
    onRemove: (AppItem) -> Unit
) {
    if (apps.isEmpty()) {
        Box(modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
            Text(emptyText, style = MaterialTheme.typography.bodyLarge)
        }
        return
    }
    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(apps, key = { it.pkg }) { app ->
            var menu by remember { mutableStateOf(false) }
            Box(Modifier.fillMaxWidth()) {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
                    modifier = Modifier.fillMaxWidth().pointerInput(app.pkg) {
                        detectTapGestures(onLongPress = { menu = true }, onTap = { onOpen(app) })
                    }
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(start = 12.dp, top = 12.dp, bottom = 12.dp, end = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Image(app.icon, null, Modifier.size(48.dp))
                        Column(Modifier.weight(1f)) {
                            Text(app.label, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                            Text(
                                app.pkg, style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1
                            )
                        }
                        IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, "Menü") }
                    }
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Aç") }, onClick = { menu = false; onOpen(app) })
                    if (app.removable) {
                        DropdownMenuItem(
                            text = { Text("Kaldır", color = MaterialTheme.colorScheme.error) },
                            onClick = { menu = false; onRemove(app) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(s: AppSettings) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        SectionCard("Görünüm") {
            Text("Tema", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Sistem", "Açık", "Koyu").forEachIndexed { i, name ->
                    FilterChip(
                        selected = s.theme == i,
                        onClick = { s.updateTheme(i) },
                        label = { Text(name) }
                    )
                }
            }
            if (Build.VERSION.SDK_INT >= 31) {
                SwitchRow("Dinamik renk", "Renkler duvar kağıdına uyar", s.dynamic) { s.updateDynamic(it) }
            }
        }
        SectionCard("İpuçları") {
            Text(
                "Bir uygulamayı kaldırmak için Klonlarım listesinde üzerine basılı tut. " +
                    "Klon alanını tamamen silmek için telefon ayarlarında \"çalışma profili\" ara.",
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
    ) {
        Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
            content()
        }
    }
}

@Composable
fun SwitchRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

package com.oguzhn.klonlayici

import android.Manifest
import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color as AColor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.UserHandle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** Kalıcı ayarlar (tema, dinamik renk, sistem uygulamaları) */
class AppSettings(ctx: Context) {
    private val sp = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var theme by mutableIntStateOf(sp.getInt("theme", 0))   // 0 sistem, 1 açık, 2 koyu
        private set
    var dynamic by mutableStateOf(sp.getBoolean("dynamic", true))
        private set
    var showSystem by mutableStateOf(sp.getBoolean("system", false))
        private set

    fun updateTheme(v: Int) { theme = v; sp.edit().putInt("theme", v).apply() }
    fun updateDynamic(v: Boolean) { dynamic = v; sp.edit().putBoolean("dynamic", v).apply() }
    var hidden by mutableStateOf(sp.getBoolean("hidden", false))
        private set
    fun updateHidden(v: Boolean) { hidden = v; sp.edit().putBoolean("hidden", v).apply() }

    fun updateShowSystem(v: Boolean) { showSystem = v; sp.edit().putBoolean("system", v).apply() }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val settings = AppSettings(applicationContext)
        setContent { KlonTheme(settings) { Root(settings) } }
    }
}

@Composable
fun KlonTheme(s: AppSettings, content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val dark = when (s.theme) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    val scheme = when {
        s.dynamic && Build.VERSION.SDK_INT >= 31 ->
            if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    val activity = ctx as? ComponentActivity
    SideEffect {
        val bars = if (dark) SystemBarStyle.dark(AColor.TRANSPARENT)
        else SystemBarStyle.light(AColor.TRANSPARENT, AColor.TRANSPARENT)
        activity?.enableEdgeToEdge(statusBarStyle = bars, navigationBarStyle = bars)
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun Root(settings: AppSettings) {
    val ctx = LocalContext.current
    val inside = remember { ProfileHelper.isInsideProfile(ctx) }
    // Profil tarafı her açılışta kendini onarır (klon filtresi / CloneActivity)
    if (inside) LaunchedEffect(Unit) {
        withContext(Dispatchers.Default) { ProfileHelper.setupProfileSide(ctx) }
        Toast.makeText(ctx, "Klon alanı hazır. Ana taraftaki uygulamadan devam edebilirsin.", Toast.LENGTH_LONG).show()
    }
    var tick by remember { mutableIntStateOf(0) }

    // Ekrana her dönüşte durumu yenile
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    if (inside) InsideScreen() else PersonalScreen(settings, tick) { tick++ }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InsideScreen() {
    Scaffold(topBar = { TopAppBar(title = { Text("Klon Alanı") }) }) { pad ->
        Column(
            Modifier.padding(pad).padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Klon alanı hazır", style = MaterialTheme.typography.headlineSmall)
            Text(
                "Uygulama seçmek için ana taraftaki Klon Çalıştırıcı'yı aç. " +
                    "Klonlanan uygulamalar buradaki rozetli simgelerle çalışır.",
                style = MaterialTheme.typography.bodyLarge
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PersonalScreen(settings: AppSettings, tick: Int, refresh: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val profile = remember(tick) { ProfileHelper.findProfile(ctx) }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var query by rememberSaveable { mutableStateOf("") }
    var path by rememberSaveable { mutableStateOf(Files.root().absolutePath) }
    var apkOnly by rememberSaveable { mutableStateOf(false) }

    // Ağır iş (uygulama listesi + simgeler) arka planda
    val loaded by produceState(Loaded(), profile, tick) {
        value = withContext(Dispatchers.Default) {
            ProfileHelper.load(ctx, profile, false)
        }
    }

    val setup = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        refresh()
        if (r.resultCode != Activity.RESULT_OK) {
            Toast.makeText(ctx, "Kurulum tamamlanmadı", Toast.LENGTH_SHORT).show()
        }
    }

    Scaffold(
        modifier = Modifier.imePadding(),
        topBar = { TopAppBar(title = { Text("Klon Çalıştırıcı", fontWeight = FontWeight.SemiBold) }) },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == 0, onClick = { tab = 0; query = "" },
                    icon = { Icon(Icons.Filled.Home, null) }, label = { Text("Klonlarım") }
                )
                NavigationBarItem(
                    selected = tab == 1, onClick = { tab = 1 },
                    icon = { FolderGlyph(LocalContentColor.current, Modifier.size(24.dp)) },
                    label = { Text("Dosyalar") }
                )
                NavigationBarItem(
                    selected = tab == 2, onClick = { tab = 2 },
                    icon = { Icon(Icons.Filled.Settings, null) }, label = { Text("Ayarlar") }
                )
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (tab == 2) {
                SettingsScreen(settings)
            } else if (tab == 1) {
                FilesScreen(profile, tick, settings, path, { path = it }, apkOnly, { apkOnly = it }, refresh)
            } else if (profile == null) {
                SetupCard {
                    val i = Intent(DevicePolicyManager.ACTION_PROVISION_MANAGED_PROFILE)
                        .putExtra(
                            DevicePolicyManager.EXTRA_PROVISIONING_DEVICE_ADMIN_COMPONENT_NAME,
                            ComponentName(ctx, AdminReceiver::class.java)
                        )
                    runCatching { setup.launch(i) }.onFailure {
                        Toast.makeText(ctx, "Bu cihazda klon alanı kurulamadı", Toast.LENGTH_LONG).show()
                    }
                }
            } else {
                if (!loaded.ready) LinearProgressIndicator(Modifier.fillMaxWidth())
                SearchField(query) { query = it }

                val list = remember(loaded, query) { loaded.clones.filterQuery(query) }
                val emptyText = when {
                    !loaded.ready -> "Yükleniyor…"
                    loaded.clones.isEmpty() -> "Henüz uygulama yok. Klon alanındaki Play Store'dan uygulama indirebilirsin."
                    else -> "Sonuç bulunamadı"
                }

                AppList(
                    apps = list,
                    emptyText = emptyText,
                    modifier = Modifier.weight(1f),
                    onOpen = { app ->
                        if (!ProfileHelper.launch(ctx, app, profile)) {
                            Toast.makeText(ctx, "Ana ekrandaki rozetli simgeden aç", Toast.LENGTH_LONG).show()
                        }
                    },
                    onRemove = { app ->
                        if (ProfileHelper.requestRemove(ctx, app.pkg)) {
                            scope.launch { delay(2000); refresh(); delay(4000); refresh() }
                        } else {
                            ProfileHelper.openProfileSide(ctx, profile)
                            Toast.makeText(
                                ctx,
                                "Klon alanı onarılıyor. Açılan ekrandan geri dönüp tekrar dene.",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun SearchField(value: String, onChange: (String) -> Unit) {
    val focus = LocalFocusManager.current
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        placeholder = { Text("Uygulama ara") },
        leadingIcon = { Icon(Icons.Filled.Search, null) },
        trailingIcon = {
            if (value.isNotEmpty()) {
                IconButton(onClick = { onChange("") }) { Icon(Icons.Filled.Close, "Temizle") }
            }
        },
        singleLine = true,
        shape = RoundedCornerShape(28.dp),
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { focus.clearFocus() })
    )
}

@Composable
fun SetupCard(onSetup: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        ElevatedCard(shape = RoundedCornerShape(28.dp)) {
            Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Klon alanını kur", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
                Text(
                    "Android'in resmi çalışma profili özelliği kullanılır. " +
                        "Seçtiğin uygulamalar bu ayrı alanda ikinci kopya olarak çalışır; " +
                        "verileri ana uygulamayla karışmaz.",
                    style = MaterialTheme.typography.bodyMedium
                )
                Button(onClick = onSetup, modifier = Modifier.fillMaxWidth()) { Text("Kurulumu başlat") }
            }
        }
    }
}

@Composable
fun AppList(
    apps: List<AppItem>,
    emptyText: String,
    modifier: Modifier = Modifier,
    onOpen: (AppItem) -> Unit,
    onRemove: (AppItem) -> Unit
) {
    if (apps.isEmpty()) {
        Box(modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
            Text(emptyText, style = MaterialTheme.typography.bodyLarge)
        }
        return
    }
    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(apps, key = { it.pkg }) { app ->
            var menu by remember { mutableStateOf(false) }
            Box(Modifier.fillMaxWidth()) {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
                    modifier = Modifier.fillMaxWidth().pointerInput(app.pkg) {
                        detectTapGestures(onLongPress = { menu = true }, onTap = { onOpen(app) })
                    }
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(start = 12.dp, top = 12.dp, bottom = 12.dp, end = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Image(app.icon, null, Modifier.size(48.dp))
                        Column(Modifier.weight(1f)) {
                            Text(app.label, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                            Text(
                                app.pkg, style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1
                            )
                        }
                        IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, "Menü") }
                    }
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Aç") }, onClick = { menu = false; onOpen(app) })
                    if (app.removable) {
                        DropdownMenuItem(
                            text = { Text("Kaldır", color = MaterialTheme.colorScheme.error) },
                            onClick = { menu = false; onRemove(app) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(s: AppSettings) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        SectionCard("Görünüm") {
            Text("Tema", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Sistem", "Açık", "Koyu").forEachIndexed { i, name ->
                    FilterChip(
                        selected = s.theme == i,
                        onClick = { s.updateTheme(i) },
                        label = { Text(name) }
                    )
                }
            }
            if (Build.VERSION.SDK_INT >= 31) {
                SwitchRow("Dinamik renk", "Renkler duvar kağıdına uyar", s.dynamic) { s.updateDynamic(it) }
            }
        }
        SectionCard("Dosyalar") {
            SwitchRow("Gizli dosyaları göster", "Adı nokta ile başlayan dosya ve klasörler", s.hidden) { s.updateHidden(it) }
        }
        SectionCard("İpuçları") {
            Text(
                "Bir uygulamayı kaldırmak için Klonlarım listesinde üzerine basılı tut. " +
                    "APK kurmak için Dosyalar sekmesinde APK'ya dokun; ilk kurulumda klon alanı için \"Bilinmeyen uygulamaları yükle\" izni istenebilir. " +
                    "Klon alanını tamamen silmek için telefon ayarlarında \"çalışma profili\" ara.",
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
    ) {
        Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
            content()
        }
    }
}

@Composable
fun SwitchRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}


// ───────────────────────── Dosyalar ─────────────────────────

private fun toast(ctx: Context, msg: String) =
    Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()

/** Köprü çalışmazsa profildeki uygulamayı açıp kendini onarmasını sağlar. */
private fun healProfile(ctx: Context, profile: UserHandle?) {
    if (profile != null) ProfileHelper.openProfileSide(ctx, profile)
    toast(ctx, "Klon alanı onarılıyor. Açılan ekrandan geri dönüp işlemi tekrar dene.")
}

@Composable
fun FilesScreen(
    profile: UserHandle?,
    tick: Int,
    settings: AppSettings,
    path: String,
    onPath: (String) -> Unit,
    apkOnly: Boolean,
    onApkOnly: (Boolean) -> Unit,
    refresh: () -> Unit
) {
    val ctx = LocalContext.current
    val root = remember { Files.root() }
    val hasAccess = remember(tick) { Files.hasAccess(ctx) }
    var query by rememberSaveable { mutableStateOf("") }
    var apk by remember { mutableStateOf<File?>(null) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { refresh() }

    val atRoot = path == root.absolutePath
    val goUp = { onPath(File(path).parentFile?.absolutePath ?: root.absolutePath); query = "" }
    BackHandler(enabled = hasAccess && !atRoot) { goUp() }

    val entries by produceState(emptyList<FileEntry>(), path, apkOnly, settings.hidden, hasAccess) {
        value = if (!hasAccess) emptyList()
        else withContext(Dispatchers.IO) { Files.list(File(path), apkOnly, settings.hidden) }
    }
    val list = remember(entries, query) {
        val q = query.trim()
        if (q.isEmpty()) entries else entries.filter { it.name.contains(q, ignoreCase = true) }
    }

    Column(Modifier.fillMaxSize()) {
        if (!hasAccess) {
            Column(
                Modifier.fillMaxSize().padding(24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                ElevatedCard(shape = RoundedCornerShape(28.dp)) {
                    Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Dosya erişimi gerekli", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
                        Text(
                            "Telefondaki dosyaları listelemek için tüm dosyalara erişim iznini vermen gerekir.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Button(
                            onClick = {
                                if (Build.VERSION.SDK_INT >= 30) {
                                    runCatching {
                                        ctx.startActivity(
                                            Intent(
                                                android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                                                Uri.parse("package:${ctx.packageName}")
                                            )
                                        )
                                    }.onFailure {
                                        runCatching {
                                            ctx.startActivity(Intent(android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                                        }
                                    }
                                } else {
                                    permLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("İzin ver") }
                    }
                }
            }
        } else {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(Files.quick()) { (name, f) ->
                    AssistChip(onClick = { onPath(f.absolutePath); query = "" }, label = { Text(name) })
                }
            }
            SearchField(query) { query = it }
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (!atRoot) {
                    IconButton(onClick = { goUp() }) { Icon(Icons.Filled.ArrowBack, "Yukarı") }
                }
                Text(
                    "Dahili depolama" + path.removePrefix(root.absolutePath),
                    modifier = Modifier.weight(1f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                FilterChip(
                    selected = apkOnly,
                    onClick = { onApkOnly(!apkOnly) },
                    label = { Text("Sadece APK") }
                )
            }
            if (list.isEmpty()) {
                Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                    Text("Bu klasörde gösterilecek bir şey yok", style = MaterialTheme.typography.bodyLarge)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(list, key = { it.file.absolutePath }) { e ->
                        FileRow(e) {
                            when {
                                e.isDir -> { onPath(e.file.absolutePath); query = "" }
                                e.isApk -> apk = e.file
                                else -> toast(ctx, "Yalnızca APK dosyaları kurulabilir")
                            }
                        }
                    }
                }
            }
        }
    }

    apk?.let { f -> InstallDialog(f, profile) { apk = null } }
}

@Composable
fun FileRow(e: FileEntry, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val (bg, fg) = when {
        e.isDir -> cs.secondaryContainer to cs.onSecondaryContainer
        e.isApk -> cs.primaryContainer to cs.onPrimaryContainer
        else -> cs.surfaceContainerHighest to cs.onSurfaceVariant
    }
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(cs.surfaceContainer)
            .pointerInput(e.file.absolutePath) { detectTapGestures(onTap = { onClick() }) }
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Box(
            Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(bg),
            contentAlignment = Alignment.Center
        ) {
            if (e.isDir) FolderGlyph(fg, Modifier.size(26.dp))
            else Text(e.ext, color = fg, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
        Column(Modifier.weight(1f)) {
            Text(e.name, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                if (e.isDir) Files.formatDate(e.modified)
                else Files.formatSize(e.size) + " · " + Files.formatDate(e.modified),
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant
            )
        }
    }
}

@Composable
fun InstallDialog(file: File, profile: UserHandle?, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val info by produceState<ApkInfo?>(null, file) {
        value = withContext(Dispatchers.IO) { Files.readApk(ctx, file) }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(28.dp),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                info?.icon?.let { Image(it, null, Modifier.size(52.dp).clip(RoundedCornerShape(14.dp))) }
                Text(info?.label ?: file.name, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(info?.pkg ?: "Paket bilgisi okunuyor…", style = MaterialTheme.typography.bodyMedium)
                Text(
                    listOfNotNull(
                        info?.version?.takeIf { it.isNotBlank() }?.let { "Sürüm $it" },
                        Files.formatSize(file.length())
                    ).joinToString(" · "),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    "Uygulama klon alanına kurulur. Android bir onay ekranı gösterebilir.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onDismiss()
                if (profile == null) toast(ctx, "Önce Klonlarım sekmesinden klon alanını kur")
                else if (!ProfileHelper.requestInstall(ctx, file)) healProfile(ctx, profile)
            }) { Text("Klon alanına kur") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Vazgeç") } }
    )
}

/** Klasör simgesi (ek ikon kütüphanesi gerektirmez). */
@Composable
fun FolderGlyph(color: Color, modifier: Modifier = Modifier.size(24.dp)) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val r = CornerRadius(w * 0.12f, w * 0.12f)
        drawRoundRect(color, topLeft = Offset(w * 0.04f, h * 0.16f), size = Size(w * 0.42f, h * 0.3f), cornerRadius = r)
        drawRoundRect(color, topLeft = Offset(w * 0.04f, h * 0.28f), size = Size(w * 0.92f, h * 0.56f), cornerRadius = r)
    }
}

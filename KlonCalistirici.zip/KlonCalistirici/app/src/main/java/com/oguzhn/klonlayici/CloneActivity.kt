package com.oguzhn.klonlayici

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast

/** Klon alanında (profil sahibi olarak) çalışır; uygulamayı profile kurar veya kaldırır. */
class CloneActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pkg = intent.getStringExtra(ProfileHelper.EXTRA_PKG)
        val dpm = getSystemService(DevicePolicyManager::class.java)
        val admin = ComponentName(this, AdminReceiver::class.java)

        if (intent.getBooleanExtra(ProfileHelper.EXTRA_REMOVE, false)) {
            if (pkg != null && pkg != packageName && dpm.isProfileOwnerApp(packageName)) {
                runCatching { startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg"))) }
                    .onFailure { Toast.makeText(this, "Kaldırma ekranı açılamadı", Toast.LENGTH_SHORT).show() }
            }
            finish()
            return
        }

        val ok = pkg != null && dpm.isProfileOwnerApp(packageName) &&
            runCatching { dpm.installExistingPackage(admin, pkg) }.getOrDefault(false)

        Toast.makeText(
            this,
            if (ok) "Klon alanına eklendi" else "Klonlama başarısız",
            Toast.LENGTH_SHORT
        ).show()
        setResult(if (ok) RESULT_OK else RESULT_CANCELED)
        finish()
    }
}

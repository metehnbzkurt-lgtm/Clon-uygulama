package com.oguzhn.klonlayici

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.os.Bundle
import android.widget.Toast

/** Klon alanında (profil sahibi olarak) çalışır ve seçilen uygulamayı profile kurar. */
class CloneActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pkg = intent.getStringExtra(ProfileHelper.EXTRA_PKG)
        val dpm = getSystemService(DevicePolicyManager::class.java)
        val admin = ComponentName(this, AdminReceiver::class.java)

        val ok = pkg != null && dpm.isProfileOwnerApp(packageName) &&
            runCatching { dpm.installExistingPackage(admin, pkg) }.getOrDefault(false)

        Toast.makeText(
            this,
            if (ok) "Klon alanına eklendi" else "Klonlama başarısız",
            Toast.LENGTH_SHORT
        ).show()
        setResult(if (ok) RESULT_OK else RESULT_CANCELED)
        finish()
    }
}

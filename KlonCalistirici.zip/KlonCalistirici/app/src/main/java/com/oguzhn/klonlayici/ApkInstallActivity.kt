package com.oguzhn.klonlayici

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast

object ApkInstaller {
    /** APK'yı sistem kurucusuyla kurar; "bilinmeyen kaynak" izni yoksa ilgili ayar ekranını açar. */
    fun install(ctx: Context, uri: Uri) {
        if (!ctx.packageManager.canRequestPackageInstalls()) {
            Toast.makeText(
                ctx,
                "Önce 'Bu kaynaktan izin ver' seçeneğini aç, sonra APK'yı tekrar seç",
                Toast.LENGTH_LONG
            ).show()
            runCatching {
                ctx.startActivity(
                    Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
            return
        }
        runCatching {
            @Suppress("DEPRECATION")
            val i = Intent(Intent.ACTION_INSTALL_PACKAGE).apply {
                data = uri
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                putExtra(Intent.EXTRA_RETURN_RESULT, false)
            }
            ctx.startActivity(i)
        }.onFailure {
            Toast.makeText(ctx, "Kurulum ekranı açılamadı", Toast.LENGTH_LONG).show()
        }
    }
}

/** Klon alanında APK'ya dokunulunca (dosya yöneticisi, tarayıcı indirmesi) açılır. */
class ApkInstallActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        intent?.data?.let { ApkInstaller.install(this, it) }
        finish()
    }
}

package com.oguzhn.klonlayici

import android.app.Activity
import android.app.PendingIntent
import android.app.admin.DevicePolicyManager
import android.content.Intent
import android.content.pm.PackageInstaller
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast

/**
 * Klon alanında (profil sahibi olarak) çalışır.
 * Ana taraftan gelen "APK kur" ve "uygulamayı kaldır" isteklerini yerine getirir.
 */
class ProfileActionActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handle(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent != null) {
            setIntent(intent)
            handle(intent)
        }
    }

    private fun handle(i: Intent) {
        val dpm = getSystemService(DevicePolicyManager::class.java)
        if (!dpm.isProfileOwnerApp(packageName)) {
            done("Bu işlem yalnızca klon alanında yapılabilir")
            return
        }
        when (i.action) {
            ProfileHelper.ACTION_INSTALL_APK -> install(i)
            ProfileHelper.ACTION_UNINSTALL -> uninstall(i)
            ProfileHelper.ACTION_INSTALL_RESULT -> onInstallResult(i)
            else -> finish()
        }
    }

    private fun install(i: Intent) {
        val uri: Uri? = i.data
        if (uri == null) {
            done("APK dosyası bulunamadı")
            return
        }
        if (!packageManager.canRequestPackageInstalls()) {
            Toast.makeText(
                this,
                "Bu uygulama için \"Bilinmeyen uygulamaları yükle\" iznini aç, sonra APK'yı tekrar seç",
                Toast.LENGTH_LONG
            ).show()
            runCatching {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName"))
                )
            }
            finish()
            return
        }
        Toast.makeText(this, "Kurulum hazırlanıyor…", Toast.LENGTH_SHORT).show()
        val self = this
        Thread {
            try {
                val installer = packageManager.packageInstaller
                val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
                val id = installer.createSession(params)
                installer.openSession(id).use { session ->
                    val input = contentResolver.openInputStream(uri)
                        ?: throw IllegalStateException("Dosya okunamadı")
                    input.use { ins ->
                        session.openWrite("apk", 0, -1).use { out ->
                            ins.copyTo(out)
                            session.fsync(out)
                        }
                    }
                    val result = PendingIntent.getActivity(
                        self, id,
                        Intent(self, ProfileActionActivity::class.java)
                            .setAction(ProfileHelper.ACTION_INSTALL_RESULT),
                        PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                    )
                    session.commit(result.intentSender)
                }
            } catch (e: Exception) {
                runOnUiThread { done("Kurulum başlatılamadı: ${e.message}") }
            }
        }.start()
    }

    private fun onInstallResult(i: Intent) {
        when (i.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE)) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                val confirm: Intent? = if (Build.VERSION.SDK_INT >= 33) {
                    i.getParcelableExtra(Intent.EXTRA_INTENT, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    i.getParcelableExtra(Intent.EXTRA_INTENT)
                }
                if (confirm != null) startActivity(confirm) else done("Onay ekranı açılamadı")
            }
            PackageInstaller.STATUS_SUCCESS -> done("Klon alanına kuruldu")
            PackageInstaller.STATUS_FAILURE_ABORTED -> done("Kurulum iptal edildi")
            else -> done("Kurulum başarısız: " + (i.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE) ?: "bilinmeyen hata"))
        }
    }

    private fun uninstall(i: Intent) {
        val pkg = i.getStringExtra(ProfileHelper.EXTRA_PKG)
        if (pkg == null || pkg == packageName) {
            done("Bu uygulama kaldırılamaz")
            return
        }
        runCatching { startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg"))) }
            .onFailure { Toast.makeText(this, "Kaldırma ekranı açılamadı", Toast.LENGTH_SHORT).show() }
        finish()
    }

    private fun done(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        finish()
    }
}

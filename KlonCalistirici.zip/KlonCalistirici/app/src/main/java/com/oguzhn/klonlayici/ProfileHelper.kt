package com.oguzhn.klonlayici

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.LauncherApps
import android.os.Process
import android.os.UserHandle
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import java.util.Locale

data class AppItem(
    val label: String,
    val pkg: String,
    val icon: ImageBitmap,
    val component: ComponentName? = null,
    val cloned: Boolean = false
)

data class Loaded(
    val clones: List<AppItem> = emptyList(),
    val personal: List<AppItem> = emptyList(),
    val ready: Boolean = false
)

object ProfileHelper {
    const val ACTION_CLONE = "com.oguzhn.klonlayici.CLONE"
    const val EXTRA_PKG = "pkg"

    private const val ICON_PX = 96
    private val TR = Locale("tr", "TR")

    fun isInsideProfile(ctx: Context): Boolean =
        ctx.getSystemService(DevicePolicyManager::class.java).isProfileOwnerApp(ctx.packageName)

    fun findProfile(ctx: Context): UserHandle? =
        ctx.getSystemService(LauncherApps::class.java).profiles
            .firstOrNull { it != Process.myUserHandle() }

    private fun isPureSystem(ai: ApplicationInfo): Boolean =
        (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
            (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0

    /** Arka planda çağrılmalı: listeleri ve simgeleri hazırlar. */
    fun load(ctx: Context, profile: UserHandle?, showSystem: Boolean): Loaded {
        val la = ctx.getSystemService(LauncherApps::class.java)
        val pm = ctx.packageManager

        val clones = if (profile == null) emptyList() else
            la.getActivityList(null, profile)
                .filter { it.applicationInfo.packageName != ctx.packageName }
                .distinctBy { it.applicationInfo.packageName }
                .map {
                    AppItem(
                        label = it.label.toString(),
                        pkg = it.applicationInfo.packageName,
                        icon = it.getIcon(0).toBitmap(ICON_PX, ICON_PX).asImageBitmap(),
                        component = it.componentName,
                        cloned = true
                    )
                }
                .sortedBy { it.label.lowercase(TR) }

        val clonedPkgs = clones.map { it.pkg }.toSet()
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val personal = pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != ctx.packageName }
            .distinctBy { it.activityInfo.packageName }
            .filter { showSystem || !isPureSystem(it.activityInfo.applicationInfo) }
            .map {
                AppItem(
                    label = it.loadLabel(pm).toString(),
                    pkg = it.activityInfo.packageName,
                    icon = it.loadIcon(pm).toBitmap(ICON_PX, ICON_PX).asImageBitmap(),
                    cloned = it.activityInfo.packageName in clonedPkgs
                )
            }
            .sortedBy { it.label.lowercase(TR) }

        return Loaded(clones, personal, true)
    }

    fun requestClone(ctx: Context, pkg: String): Boolean =
        runCatching { ctx.startActivity(Intent(ACTION_CLONE).putExtra(EXTRA_PKG, pkg)) }.isSuccess

    fun launch(ctx: Context, app: AppItem, profile: UserHandle): Boolean {
        val c = app.component ?: return false
        return runCatching {
            ctx.getSystemService(LauncherApps::class.java).startMainActivity(c, profile, null, null)
        }.isSuccess
    }
}

fun List<AppItem>.filterQuery(q: String): List<AppItem> {
    val s = q.trim().lowercase(Locale("tr", "TR"))
    if (s.isEmpty()) return this
    return filter {
        it.label.lowercase(Locale("tr", "TR")).contains(s) || it.pkg.contains(s, ignoreCase = true)
    }
}

package com.oguzhn.klonlayici

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.graphics.drawable.Drawable
import android.os.Process
import android.os.UserHandle

data class AppItem(
    val label: String,
    val pkg: String,
    val icon: Drawable,
    val component: ComponentName? = null,
    val cloned: Boolean = false
)

object ProfileHelper {
    const val ACTION_CLONE = "com.oguzhn.klonlayici.CLONE"
    const val EXTRA_PKG = "pkg"

    fun isInsideProfile(ctx: Context): Boolean =
        ctx.getSystemService(DevicePolicyManager::class.java).isProfileOwnerApp(ctx.packageName)

    fun findProfile(ctx: Context): UserHandle? =
        ctx.getSystemService(LauncherApps::class.java).profiles
            .firstOrNull { it != Process.myUserHandle() }

    /** Klon alanındaki (profildeki) uygulamalar */
    fun cloneApps(ctx: Context, profile: UserHandle): List<AppItem> =
        ctx.getSystemService(LauncherApps::class.java)
            .getActivityList(null, profile)
            .filter { it.applicationInfo.packageName != ctx.packageName }
            .map {
                AppItem(
                    label = it.label.toString(),
                    pkg = it.applicationInfo.packageName,
                    icon = it.getIcon(0),
                    component = it.componentName,
                    cloned = true
                )
            }
            .sortedBy { it.label.lowercase() }

    /** Ana taraftaki klonlanabilir uygulamalar */
    fun personalApps(ctx: Context, clonedPkgs: Set<String>): List<AppItem> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != ctx.packageName }
            .distinctBy { it.activityInfo.packageName }
            .map {
                AppItem(
                    label = it.loadLabel(pm).toString(),
                    pkg = it.activityInfo.packageName,
                    icon = it.loadIcon(pm),
                    cloned = it.activityInfo.packageName in clonedPkgs
                )
            }
            .sortedBy { it.label.lowercase() }
    }

    fun requestClone(ctx: Context, pkg: String) {
        ctx.startActivity(Intent(ACTION_CLONE).putExtra(EXTRA_PKG, pkg))
    }

    fun launch(ctx: Context, app: AppItem, profile: UserHandle): Boolean {
        val c = app.component ?: return false
        return runCatching {
            ctx.getSystemService(LauncherApps::class.java).startMainActivity(c, profile, null, null)
        }.isSuccess
    }
}

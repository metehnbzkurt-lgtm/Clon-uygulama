package com.oguzhn.klonlayici

import android.app.admin.DevicePolicyManager
import android.content.ClipData
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.os.Process
import android.os.UserHandle
import android.os.UserManager
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import java.io.File
import java.util.Locale

data class AppItem(
    val label: String,
    val pkg: String,
    val icon: ImageBitmap,
    val component: ComponentName,
    val removable: Boolean
)

data class Loaded(
    val clones: List<AppItem> = emptyList(),
    val ready: Boolean = false
)

object ProfileHelper {
    const val ACTION_INSTALL_APK = "com.oguzhn.klonlayici.INSTALL_APK"
    const val ACTION_UNINSTALL = "com.oguzhn.klonlayici.UNINSTALL"
    const val ACTION_INSTALL_RESULT = "com.oguzhn.klonlayici.INSTALL_RESULT"
    const val EXTRA_PKG = "pkg"
    const val APK_MIME = "application/vnd.android.package-archive"

    private const val ICON_PX = 96
    private val TR = Locale("tr", "TR")

    fun isInsideProfile(ctx: Context): Boolean =
        ctx.getSystemService(DevicePolicyManager::class.java).isProfileOwnerApp(ctx.packageName)

    fun findProfile(ctx: Context): UserHandle? =
        ctx.getSystemService(LauncherApps::class.java).profiles
            .firstOrNull { it != Process.myUserHandle() }

    private fun isPureSystem(ai: ApplicationInfo): Boolean =
        (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
            (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0

    /** Arka planda çağrılmalı: klon alanındaki uygulamaları ve simgelerini hazırlar. */
    fun load(ctx: Context, profile: UserHandle?): Loaded {
        if (profile == null) return Loaded(ready = true)
        val la = ctx.getSystemService(LauncherApps::class.java)
        val clones = la.getActivityList(null, profile)
            .filter { it.applicationInfo.packageName != ctx.packageName }
            .distinctBy { it.applicationInfo.packageName }
            .map {
                AppItem(
                    label = it.label.toString(),
                    pkg = it.applicationInfo.packageName,
                    icon = it.getIcon(0).toBitmap(ICON_PX, ICON_PX).asImageBitmap(),
                    component = it.componentName,
                    removable = !isPureSystem(it.applicationInfo)
                )
            }
            .sortedBy { it.label.lowercase(TR) }
        return Loaded(clones, true)
    }

    /**
     * Profil tarafında (profil sahibi olarak) çalışır; her adım ayrı korunur.
     * Hem kurulum sonunda hem de profildeki uygulama her açıldığında çağrılır (kendini onarır).
     */
    fun setupProfileSide(ctx: Context) {
        val dpm = ctx.getSystemService(DevicePolicyManager::class.java)
        if (!dpm.isProfileOwnerApp(ctx.packageName)) return
        val admin = ComponentName(ctx, AdminReceiver::class.java)

        runCatching {
            ctx.packageManager.setComponentEnabledSetting(
                ComponentName(ctx, ProfileActionActivity::class.java),
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                PackageManager.DONT_KILL_APP
            )
        }
        runCatching { dpm.clearCrossProfileIntentFilters(admin) }
        runCatching {
            val install = IntentFilter(ACTION_INSTALL_APK).apply {
                addCategory(Intent.CATEGORY_DEFAULT)
                addDataType(APK_MIME)
            }
            dpm.addCrossProfileIntentFilter(admin, install, DevicePolicyManager.FLAG_PARENT_CAN_ACCESS_MANAGED)
        }
        runCatching {
            val remove = IntentFilter(ACTION_UNINSTALL).apply { addCategory(Intent.CATEGORY_DEFAULT) }
            dpm.addCrossProfileIntentFilter(admin, remove, DevicePolicyManager.FLAG_PARENT_CAN_ACCESS_MANAGED)
        }
        // Klon alanında APK kurulumuna izin ver
        runCatching { dpm.clearUserRestriction(admin, UserManager.DISALLOW_INSTALL_UNKNOWN_SOURCES) }
        runCatching { dpm.clearUserRestriction(admin, UserManager.DISALLOW_INSTALL_UNKNOWN_SOURCES_GLOBALLY) }
        runCatching { dpm.setProfileName(admin, "Klon Alanı") }
        runCatching { dpm.setProfileEnabled(admin) }
    }

    /** Ana taraftan: profildeki Klon Çalıştırıcı'yı açar (profil tarafı onarımı tetikler). */
    fun openProfileSide(ctx: Context, profile: UserHandle): Boolean = runCatching {
        val la = ctx.getSystemService(LauncherApps::class.java)
        val c = la.getActivityList(ctx.packageName, profile).first().componentName
        la.startMainActivity(c, profile, null, null)
    }.isSuccess

    /** Ana taraftan: seçilen APK'yı klon alanına kurması için profile iletir. */
    fun requestInstall(ctx: Context, file: File): Boolean = runCatching {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", file)
        val i = Intent(ACTION_INSTALL_APK)
            .setDataAndType(uri, APK_MIME)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        i.clipData = ClipData.newRawUri("apk", uri)
        ctx.startActivity(i)
    }.isSuccess

    /** Ana taraftan: klon alanındaki bir uygulamanın kaldırılmasını ister. */
    fun requestUninstall(ctx: Context, pkg: String): Boolean = runCatching {
        ctx.startActivity(Intent(ACTION_UNINSTALL).putExtra(EXTRA_PKG, pkg))
    }.isSuccess

    fun launch(ctx: Context, app: AppItem, profile: UserHandle): Boolean = runCatching {
        ctx.getSystemService(LauncherApps::class.java).startMainActivity(app.component, profile, null, null)
    }.isSuccess

    fun openAppInfo(ctx: Context, app: AppItem, profile: UserHandle): Boolean = runCatching {
        ctx.getSystemService(LauncherApps::class.java).startAppDetailsActivity(app.component, profile, null, null)
    }.isSuccess
}

fun List<AppItem>.filterQuery(q: String): List<AppItem> {
    val s = q.trim().lowercase(Locale("tr", "TR"))
    if (s.isEmpty()) return this
    return filter {
        it.label.lowercase(Locale("tr", "TR")).contains(s) || it.pkg.contains(s, ignoreCase = true)
    }
}

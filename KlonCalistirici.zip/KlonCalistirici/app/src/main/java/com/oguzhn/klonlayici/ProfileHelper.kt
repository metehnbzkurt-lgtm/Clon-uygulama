package com.oguzhn.klonlayici

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.LauncherApps
import android.os.Process
import android.os.UserHandle
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import java.util.Locale

data class AppItem(
    val label: String,
    val pkg: String,
    val icon: ImageBitmap,
    val component: ComponentName? = null,
    val cloned: Boolean = false,
    val removable: Boolean = true
)

data class Loaded(
    val clones: List<AppItem> = emptyList(),
    val personal: List<AppItem> = emptyList(),
    val ready: Boolean = false
)

object ProfileHelper {
    const val ACTION_CLONE = "com.oguzhn.klonlayici.CLONE"
    const val EXTRA_PKG = "pkg"
    const val EXTRA_REMOVE = "remove"

    private const val ICON_PX = 96
    private val TR = Locale("tr", "TR")

    fun isInsideProfile(ctx: Context): Boolean =
        ctx.getSystemService(DevicePolicyManager::class.java).isProfileOwnerApp(ctx.packageName)

    fun findProfile(ctx: Context): UserHandle? =
        ctx.getSystemService(LauncherApps::class.java).profiles
            .firstOrNull { it != Process.myUserHandle() }

    private fun isPureSystem(ai: ApplicationInfo): Boolean =
        (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
            (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0

    /** Arka planda çağrılmalı: listeleri ve simgeleri hazırlar. */
    fun load(ctx: Context, profile: UserHandle?, showSystem: Boolean): Loaded {
        val la = ctx.getSystemService(LauncherApps::class.java)

        val clones = if (profile == null) emptyList() else
            la.getActivityList(null, profile)
                .filter { it.applicationInfo.packageName != ctx.packageName }
                .distinctBy { it.applicationInfo.packageName }
                .map {
                    AppItem(
                        label = it.label.toString(),
                        pkg = it.applicationInfo.packageName,
                        icon = it.getIcon(0).toBitmap(ICON_PX, ICON_PX).asImageBitmap(),
                        component = it.componentName,
                        cloned = true,
                        removable = !isPureSystem(it.applicationInfo) &&
                            it.applicationInfo.packageName != "com.android.vending"
                    )
                }
                .sortedBy { it.label.lowercase(TR) }

        return Loaded(clones, emptyList(), true)
    }

    fun requestClone(ctx: Context, pkg: String): Boolean =
        runCatching { ctx.startActivity(Intent(ACTION_CLONE).putExtra(EXTRA_PKG, pkg)) }.isSuccess

    /** Klon alanındaki bir uygulamanın kaldırılmasını ister (mevcut köprü üzerinden). */
    fun requestRemove(ctx: Context, pkg: String): Boolean =
        runCatching {
            ctx.startActivity(Intent(ACTION_CLONE).putExtra(EXTRA_PKG, pkg).putExtra(EXTRA_REMOVE, true))
        }.isSuccess

    /**
     * Profil tarafında (profil sahibi olarak) çalışır; her adım ayrı korunur.
     * Hem kurulum sonunda hem de profildeki uygulama her açıldığında çağrılır (kendini onarır).
     */
    fun setupProfileSide(ctx: Context) {
        val dpm = ctx.getSystemService(DevicePolicyManager::class.java)
        if (!dpm.isProfileOwnerApp(ctx.packageName)) return
        val admin = ComponentName(ctx, AdminReceiver::class.java)

        runCatching {
            ctx.packageManager.setComponentEnabledSetting(
                ComponentName(ctx, CloneActivity::class.java),
                android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                android.content.pm.PackageManager.DONT_KILL_APP
            )
        }
        runCatching {
            ctx.packageManager.setComponentEnabledSetting(
                ComponentName(ctx, ApkInstallActivity::class.java),
                android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                android.content.pm.PackageManager.DONT_KILL_APP
            )
        }
        // Klon alanında harici (Play Store dışı) APK kurulumuna izin ver
        runCatching { dpm.clearUserRestriction(admin, android.os.UserManager.DISALLOW_INSTALL_UNKNOWN_SOURCES) }
        runCatching { dpm.clearUserRestriction(admin, android.os.UserManager.DISALLOW_INSTALL_UNKNOWN_SOURCES_GLOBALLY) }
        runCatching {
            dpm.clearCrossProfileIntentFilters(admin)
            val filter = android.content.IntentFilter(ACTION_CLONE).apply {
                addCategory(Intent.CATEGORY_DEFAULT)
            }
            dpm.addCrossProfileIntentFilter(
                admin, filter, DevicePolicyManager.FLAG_MANAGED_CAN_ACCESS_PARENT
            )
        }
        runCatching { dpm.setProfileName(admin, "Klon Alanı") }
        runCatching { dpm.setProfileEnabled(admin) }
    }

    /** Ana taraftan: profildeki Klon Çalıştırıcı'yı açar (profil tarafı onarımı tetikler). */
    fun openProfileSide(ctx: Context, profile: UserHandle): Boolean = runCatching {
        val la = ctx.getSystemService(LauncherApps::class.java)
        val c = la.getActivityList(ctx.packageName, profile).first().componentName
        la.startMainActivity(c, profile, null, null)
    }.isSuccess

    fun launch(ctx: Context, app: AppItem, profile: UserHandle): Boolean {
        val c = app.component ?: return false
        return runCatching {
            ctx.getSystemService(LauncherApps::class.java).startMainActivity(c, profile, null, null)
        }.isSuccess
    }
}

fun List<AppItem>.filterQuery(q: String): List<AppItem> {
    val s = q.trim().lowercase(Locale("tr", "TR"))
    if (s.isEmpty()) return this
    return filter {
        it.label.lowercase(Locale("tr", "TR")).contains(s) || it.pkg.contains(s, ignoreCase = true)
    }
}

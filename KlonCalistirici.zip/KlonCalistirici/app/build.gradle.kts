plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.oguzhn.klonlayici"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.oguzhn.klonlayici"
        minSdk = 28
        targetSdk = 34
        versionCode = 7
        versionName = "1.4.1"
        // General Mobile 24 Pro arm64: gereksiz mimarileri çıkar, APK küçülsün
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    val keystore = file("klon.keystore")
    signingConfigs {
        create("klon") {
            storeFile = keystore
            storePassword = "klon1234"
            keyAlias = "klon"
            keyPassword = "klon1234"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = if (keystore.exists()) signingConfigs.getByName("klon")
                            else signingConfigs.getByName("debug")
        }
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
}

dependencies {
    val bom = platform("androidx.compose:compose-bom:2024.09.00")
    implementation(bom)
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}

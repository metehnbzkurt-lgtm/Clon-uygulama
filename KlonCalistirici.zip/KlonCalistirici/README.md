# Klon Çalıştırıcı 1.3
Android 14 için çalışma profili tabanlı klon alanı (Compose + Material 3).
- Uygulamalar: klon alanındaki uygulamalar; basılı tutunca Aç / Uygulama bilgisi / Kaldır menüsü.
- Dosyalar: ana telefon dosyalarını gez, APK'ya dokunup klon alanına kur.
- Ayarlar: tema, dinamik renk, gizli dosyalar.

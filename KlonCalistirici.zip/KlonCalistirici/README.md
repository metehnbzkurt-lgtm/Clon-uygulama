# Klon Çalıştırıcı 1.5
Android 14 için çalışma profili tabanlı klon alanı (Compose + Material 3).
- Klonlarım: klon alanındaki uygulamalar; basılı tutunca Aç / Kaldır.
- Dosyalar: ana telefon dosyalarını gez, APK'ya dokunup klon alanına kur.
- Ayarlar: tema, dinamik renk, gizli dosyalar.

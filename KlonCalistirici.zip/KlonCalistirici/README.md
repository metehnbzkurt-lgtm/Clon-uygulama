# Klon Çalıştırıcı
Android 14 için çalışma profili tabanlı uygulama klonlayıcı (Compose + Material 3).

## Derleme (GitHub)
1. Bu klasörün içeriğini bir GitHub deposuna yükle (`.github` klasörü dahil)
2. Actions sekmesi -> "APK Derle" -> bittiğinde Artifacts'tan `KlonCalistirici-debug` indir
3. APK'yı kur, uygulamayı aç -> "Kurulumu başlat"

# Klon Çalıştırıcı 1.1
Android 14 için çalışma profili tabanlı uygulama klonlayıcı (Compose + Material 3).
Arama, ayarlar ekranı, arka plan yükleme, R8 küçültmeli release derlemesi.

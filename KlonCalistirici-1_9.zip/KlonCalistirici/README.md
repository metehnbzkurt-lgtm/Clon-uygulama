# Klon Çalıştırıcı 1.9
Android çalışma profili tabanlı klon yöneticisi (Jetpack Compose + Material 3).

## 1.9 yenilikleri (Premium Hybrid arayüz)
- Alt gezinme: Ana sayfa, Uygulamalar, Favoriler, Dosyalar ve "Daha fazla" (Geçmiş, Temalar, Profil, Ayarlar alttan açılan sayfada). Yan menü kaldırıldı.
- Ana sayfa: ince çalışma alanı kartı, üç istatistik kartı (klon uygulama, profil durumu, favori) ve favori ızgarası.
- Uygulamalar: ızgara / liste geçişi, "Tümünü seç", uzun basarak seçme ve toplu kaldırma (Android her uygulama için ayrı onay ister).
- Ayarlar: simge boyutu kaydırıcısı (40–72 dp) ve varsayılan görünüm (ızgara / liste).
- Klon altyapısı ve dosya aktarımı (1.8) aynen korundu.

## 1.8 yenilikleri
- Dashboard: çalışma alanı kartı inceltildi (tek satır başlık, kompakt düğmeler); "Son etkinlik" ana ekrandan kaldırıldı (Geçmiş bölümü menüde duruyor).
- Dashboard: favori uygulamalar yana kaydırmalı satır yerine uygulama çekmecesi gibi ızgara düzeninde.
- Dosya aktarımı (ana kişisel taraf ↔ klon alanı):
  - APK / Dosyalar: dosyaya dokun veya uzun bas → seç → **Klona gönder** (klon alanında `İndirilenler/Klon Aktarım` klasörüne kopyalanır).
  - **Klondan al**: sistem dosya seçicisi açılır (çalışma sekmesinden klon dosyaları seçilir), seçilenler bulunulan klasöre kopyalanır.
  - Klon alanındaki dosya yöneticisi / paylaş menüsü ile ana taraf arasında dosya seçme ve paylaşma için çapraz profil filtreleri eklendi (GET_CONTENT, OPEN_DOCUMENT, SEND, SEND_MULTIPLE).
- **Güncelleme sonrası bir kez** Profil bölümünde "Klon alanını aç / onar"a dokun; yeni filtreler profil tarafında bu sırada kurulur.

## 1.7 yenilikleri
Yan menü (☰) ile sekiz bölüm: **Dashboard, Uygulamalar, Favoriler, Geçmiş, APK / Dosyalar, Temalar, Profil, Ayarlar**.
- Favoriler: Uygulamalar listesinde kalp simgesiyle ekle/çıkar; Dashboard'da hızlı erişim satırı.
- Geçmiş: açılan, kurulan ve kaldırılan uygulamalar (filtreli, temizlenebilir, Ayarlar'dan kapatılabilir).
- Uygulamalar: A-Z / en çok açılan / son açılan sıralama.
- Temalar: sistem/açık/koyu, AMOLED siyah, dinamik renk ve 6 vurgu rengi.
- Profil: klon alanı durumu, kurulum/onarım, dosya erişim izni, telefon ayarlarına kısayol.
- Çalışma profili altyapısı (ProfileHelper, CloneActivity, ProfileActionActivity, AdminReceiver, manifest) değiştirilmedi; imza ve paket adı aynı olduğu için mevcut klonlar güncellemeyle korunur.

## 1.6 yenilikleri
- Premium koyu temada mor/viyole vurgu renkleri ve daha yumuşak yüzey tonları.
- Yenilenen üst başlık ve hızlı yenileme eylemi.
- Ana ekranda çalışma alanı durumu, klon sayısı ve APK/Dosyalar kısayolu.
- Klon listesinde alfabetik sıralama.
- Mevcut çalışma profili, uygulama açma/kaldırma ve APK yükleme akışı korunmuştur.

## Derleme
GitHub Actions sekmesinden `APK Derle` iş akışını `Run workflow` ile başlatın. APK, işlem tamamlandığında `KlonCalistirici-release` artifact'i altında bulunur.

## Notlar
- Uygulama Android'in yönetilen çalışma profili mekanizmasını kullanır; cihaz ve üretici politikalarına bağlı sınırlamalar olabilir.
- Mevcut kurulu uygulamanın üzerine güncelleme yapabilmek için imza anahtarını koruyun. Keystore dosyasını ve parolasını herkese açık depolarda paylaşmayın; güvenli GitHub Actions Secrets kullanımına geçiş planlayın.

package com.oguzhn.klonlayici

import android.Manifest
import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color as AColor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.UserHandle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** Kalıcı ayarlar (tema, dinamik renk, sistem uygulamaları) */
class AppSettings(ctx: Context) {
    private val sp = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var theme by mutableIntStateOf(sp.getInt("theme", 0))   // 0 sistem, 1 açık, 2 koyu
        private set
    var dynamic by mutableStateOf(sp.getBoolean("dynamic", true))
        private set
    var showSystem by mutableStateOf(sp.getBoolean("system", false))
        private set

    fun updateTheme(v: Int) { theme = v; sp.edit().putInt("theme", v).apply() }
    fun updateDynamic(v: Boolean) { dynamic = v; sp.edit().putBoolean("dynamic", v).apply() }
    var hidden by mutableStateOf(sp.getBoolean("hidden", false))
        private set
    fun updateHidden(v: Boolean) { hidden = v; sp.edit().putBoolean("hidden", v).apply() }

    fun updateShowSystem(v: Boolean) { showSystem = v; sp.edit().putBoolean("system", v).apply() }

    var accent by mutableIntStateOf(sp.getInt("accent", 0))
        private set
    var amoled by mutableStateOf(sp.getBoolean("amoled", false))
        private set
    var iconSize by mutableIntStateOf(sp.getInt("icon_size", 52))   // dp (40–72)
        private set
    var listView by mutableStateOf(sp.getBoolean("list_view", false))  // varsayılan: ızgara
        private set
    fun updateIconSize(v: Int) { iconSize = v.coerceIn(40, 72); sp.edit().putInt("icon_size", iconSize).apply() }
    fun updateListView(v: Boolean) { listView = v; sp.edit().putBoolean("list_view", v).apply() }
    fun updateAccent(v: Int) { accent = v; sp.edit().putInt("accent", v).apply() }
    fun updateAmoled(v: Boolean) { amoled = v; sp.edit().putBoolean("amoled", v).apply() }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val settings = AppSettings(applicationContext)
        setContent { KlonTheme(settings) { Root(settings) } }
    }
}

@Composable
fun KlonTheme(s: AppSettings, content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val dark = when (s.theme) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    val a = accentList[s.accent.coerceIn(0, accentList.lastIndex)]
    val base = Color(0xFF101321)
    val scheme = when {
        s.dynamic && Build.VERSION.SDK_INT >= 31 -> {
            val d = if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
            if (dark && s.amoled) d.copy(
                background = Color.Black,
                surface = Color.Black,
                surfaceContainer = Color(0xFF0E0E10),
                surfaceContainerHigh = Color(0xFF17171B)
            ) else d
        }
        dark -> darkColorScheme(
            primary = a.dark,
            onPrimary = a.onDark,
            primaryContainer = lerp(base, a.dark, 0.30f),
            onPrimaryContainer = lerp(Color.White, a.dark, 0.35f),
            secondary = Color(0xFF9BD8D0),
            background = if (s.amoled) Color.Black else base,
            surface = if (s.amoled) Color.Black else Color(0xFF171B2B),
            surfaceVariant = Color(0xFF252B40),
            surfaceContainer = if (s.amoled) Color(0xFF0E0E10) else Color(0xFF1D2336),
            surfaceContainerHigh = if (s.amoled) Color(0xFF17171B) else Color(0xFF272E45)
        )
        else -> lightColorScheme(
            primary = a.light,
            primaryContainer = lerp(Color.White, a.light, 0.20f),
            onPrimaryContainer = lerp(Color.Black, a.light, 0.60f),
            secondary = Color(0xFF287D76),
            surface = Color(0xFFF8F7FC),
            background = Color(0xFFF5F4FA)
        )
    }
    val activity = ctx as? ComponentActivity
    SideEffect {
        val bars = if (dark) SystemBarStyle.dark(AColor.TRANSPARENT)
        else SystemBarStyle.light(AColor.TRANSPARENT, AColor.TRANSPARENT)
        activity?.enableEdgeToEdge(statusBarStyle = bars, navigationBarStyle = bars)
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun Root(settings: AppSettings) {
    val ctx = LocalContext.current
    val inside = remember { ProfileHelper.isInsideProfile(ctx) }
    // Profil tarafı her açılışta kendini onarır (klon filtresi / CloneActivity)
    if (inside) LaunchedEffect(Unit) {
        withContext(Dispatchers.Default) { ProfileHelper.setupProfileSide(ctx) }
        Toast.makeText(ctx, "Klon alanı hazır. Ana taraftaki uygulamadan devam edebilirsin.", Toast.LENGTH_LONG).show()
    }
    var tick by remember { mutableIntStateOf(0) }

    // Ekrana her dönüşte durumu yenile
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    if (inside) InsideScreen() else PersonalScreen(settings, tick) { tick++ }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InsideScreen() {
    Scaffold(topBar = { TopAppBar(title = { Text("Klon Alanı") }) }) { pad ->
        Column(
            Modifier.padding(pad).padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Klon alanı hazır", style = MaterialTheme.typography.headlineSmall)
            Text(
                "Uygulama seçmek için ana taraftaki Klon Çalıştırıcı'yı aç. " +
                    "Klonlanan uygulamalar buradaki rozetli simgelerle çalışır.",
                style = MaterialTheme.typography.bodyLarge
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PersonalScreen(settings: AppSettings, tick: Int, refresh: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val store = remember { KlonStore(ctx.applicationContext) }
    val profile = remember(tick) { ProfileHelper.findProfile(ctx) }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var query by rememberSaveable { mutableStateOf("") }
    var sort by rememberSaveable { mutableIntStateOf(0) }
    var path by rememberSaveable { mutableStateOf(Files.root().absolutePath) }
    var apkOnly by rememberSaveable { mutableStateOf(false) }

    // Ağır iş (uygulama listesi + simgeler) arka planda
    val loaded by produceState(Loaded(), profile, tick) {
        value = withContext(Dispatchers.Default) {
            ProfileHelper.load(ctx, profile, false)
        }
    }

    val setup = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        refresh()
        if (r.resultCode != Activity.RESULT_OK) {
            Toast.makeText(ctx, "Kurulum tamamlanmadı", Toast.LENGTH_SHORT).show()
        }
    }
    val startSetup: () -> Unit = {
        val i = Intent(DevicePolicyManager.ACTION_PROVISION_MANAGED_PROFILE)
            .putExtra(
                DevicePolicyManager.EXTRA_PROVISIONING_DEVICE_ADMIN_COMPONENT_NAME,
                ComponentName(ctx, AdminReceiver::class.java)
            )
        runCatching { setup.launch(i) }.onFailure {
            Toast.makeText(ctx, "Bu cihazda klon alanı kurulamadı", Toast.LENGTH_LONG).show()
        }
    }

    val openApp: (AppItem) -> Unit = { app ->
        if (profile != null && ProfileHelper.launch(ctx, app, profile)) {
            store.log("open", app.label, app.pkg)
        } else {
            Toast.makeText(ctx, "Ana ekrandaki rozetli simgeden aç", Toast.LENGTH_LONG).show()
        }
    }
    val removeApp: (AppItem) -> Unit = { app ->
        if (ProfileHelper.requestRemove(ctx, app.pkg)) {
            store.log("remove", app.label, app.pkg)
            scope.launch { delay(2000); refresh(); delay(4000); refresh() }
        } else {
            if (profile != null) ProfileHelper.openProfileSide(ctx, profile)
            Toast.makeText(
                ctx,
                "Klon alanı onarılıyor. Açılan ekrandan geri dönüp tekrar dene.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    BackHandler(enabled = tab != 0) { tab = 0 }

    val removeMany: (List<AppItem>) -> Unit = { apps ->
        val targets = apps.filter { it.removable }
        if (targets.isEmpty()) {
            toast(ctx, "Seçilen uygulamalar kaldırılamaz")
        } else {
            scope.launch {
                for (app in targets) {
                    if (ProfileHelper.requestRemove(ctx, app.pkg)) {
                        store.log("remove", app.label, app.pkg)
                    } else {
                        if (profile != null) ProfileHelper.openProfileSide(ctx, profile)
                        toast(ctx, "Klon alanı onarılıyor. Açılan ekrandan geri dönüp tekrar dene.")
                        break
                    }
                    delay(800)
                }
                delay(2000); refresh(); delay(4000); refresh()
            }
        }
    }

    var more by remember { mutableStateOf(false) }
    val moreTabs = listOf(3, 5, 6, 7)

    Scaffold(
        modifier = Modifier.imePadding(),
        topBar = {
            TopAppBar(
                title = {
                    Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
                        Text(SECTIONS[tab], fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                        Text("Klon Merkezi", style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                actions = {
                    IconButton(onClick = refresh) { Icon(Icons.Filled.Refresh, contentDescription = "Yenile") }
                    Spacer(Modifier.width(4.dp))
                }
            )
        },
        bottomBar = {
            NavigationBar {
                listOf(0 to "Ana sayfa", 1 to "Uygulamalar", 2 to "Favoriler", 4 to "Dosyalar").forEach { (i, name) ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i; query = "" },
                        icon = { Icon(sectionIcon(i), null) },
                        label = { Text(name, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                    )
                }
                NavigationBarItem(
                    selected = tab in moreTabs,
                    onClick = { more = true },
                    icon = { Icon(Icons.Filled.MoreVert, null) },
                    label = { Text("Daha fazla", fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                )
            }
        }
    ) { pad ->
            Column(Modifier.padding(pad).fillMaxSize()) {
                if (profile == null && tab in 0..2) {
                    SetupCard(startSetup)
                } else {
                    when (tab) {
                        0 -> DashboardScreen(loaded, profile != null, store, settings.iconSize, openApp, { tab = it }, refresh)
                        1 -> AppsScreen(
                            loaded, store, settings, query, { query = it }, sort, { sort = it },
                            openApp, removeApp, removeMany
                        )
                        2 -> FavoritesScreen(loaded, store, settings.iconSize, openApp, removeApp)
                        3 -> HistoryScreen(store)
                        4 -> FilesScreen(profile, tick, settings, path, { path = it }, apkOnly, { apkOnly = it }, refresh, store)
                        5 -> ThemesScreen(settings)
                        6 -> ProfileScreen(profile, loaded, tick, startSetup)
                        else -> AppSettingsScreen(settings, store)
                    }
                }
            }
    }

    if (more) {
        ModalBottomSheet(onDismissRequest = { more = false }) {
            Column(Modifier.padding(bottom = 24.dp)) {
                moreTabs.forEach { i ->
                    ListItem(
                        headlineContent = { Text(if (i == 3) "İşlem geçmişi" else SECTIONS[i]) },
                        leadingContent = { Icon(sectionIcon(i), null) },
                        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                        modifier = Modifier.clickable { tab = i; query = ""; more = false }
                    )
                }
            }
        }
    }
}

@Composable
fun DashboardHeader(
    appCount: Int,
    ready: Boolean,
    profileReady: Boolean,
    onFiles: () -> Unit,
    onRefresh: () -> Unit,
    favCount: Int = 0,
    listLabel: String? = "UYGULAMALARIM"
) {
    val p = MaterialTheme.colorScheme.primary
    val hdr = lerp(Color(0xFF0B0B14), p, 0.17f)
    val chipBg = lerp(Color(0xFF0B0B14), p, 0.30f)
    val pillBg = lerp(Color(0xFF0B0B14), p, 0.24f)
    val soft = lerp(Color.White, p, 0.40f)
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // İnce çalışma alanı kartı: tek satır başlık, açıklama yok, kompakt düğmeler
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = hdr)
        ) {
            Column(
                Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(color = chipBg, shape = RoundedCornerShape(10.dp)) {
                        Icon(Icons.Filled.Shield, null, tint = soft, modifier = Modifier.padding(7.dp).size(18.dp))
                    }
                    Spacer(Modifier.width(8.dp))
                    Text("ÇALIŞMA ALANI", color = soft, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.weight(1f))
                    Surface(color = pillBg, shape = RoundedCornerShape(50)) {
                        Row(Modifier.padding(horizontal = 10.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(7.dp).clip(RoundedCornerShape(50)).background(if (profileReady) Color(0xFF7CE0B1) else Color(0xFFFFC66D)))
                            Spacer(Modifier.width(6.dp))
                            Text(if (profileReady) "Hazır" else "Kurulum gerekli", color = Color.White, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
                Text("Uygulamalarınız kontrol altında.", color = Color.White, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(
                        onClick = onFiles,
                        modifier = Modifier.height(36.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 0.dp),
                        colors = ButtonDefaults.filledTonalButtonColors(containerColor = p, contentColor = MaterialTheme.colorScheme.onPrimary)
                    ) {
                        Icon(Icons.Filled.FolderOpen, null, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("APK / Dosyalar")
                    }
                    OutlinedButton(
                        onClick = onRefresh,
                        modifier = Modifier.height(36.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 0.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                    ) {
                        Icon(Icons.Filled.Refresh, null, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Yenile")
                    }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard(
                Modifier.weight(1f), Icons.Filled.Apps,
                MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.primary,
                if (ready) appCount.toString() else "…", "Klon uygulama"
            )
            StatCard(
                Modifier.weight(1f), Icons.Filled.Shield,
                MaterialTheme.colorScheme.secondaryContainer, MaterialTheme.colorScheme.secondary,
                if (profileReady) "Aktif" else "Pasif", "Profil durumu"
            )
            StatCard(
                Modifier.weight(1f), Icons.Filled.Favorite,
                MaterialTheme.colorScheme.tertiaryContainer, MaterialTheme.colorScheme.tertiary,
                if (ready) favCount.toString() else "…", "Favori"
            )
        }
        if (listLabel != null) Text(listLabel, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun StatCard(
    modifier: Modifier,
    icon: ImageVector,
    iconBg: Color,
    iconTint: Color,
    value: String,
    label: String
) {
    Card(
        modifier,
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
    ) {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Surface(shape = RoundedCornerShape(10.dp), color = iconBg) {
                Icon(icon, null, tint = iconTint, modifier = Modifier.padding(7.dp).size(18.dp))
            }
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
        }
    }
}

@Composable
fun SearchField(value: String, onChange: (String) -> Unit) {
    val focus = LocalFocusManager.current
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        placeholder = { Text("Uygulama ara") },
        leadingIcon = { Icon(Icons.Filled.Search, null) },
        trailingIcon = {
            if (value.isNotEmpty()) {
                IconButton(onClick = { onChange("") }) { Icon(Icons.Filled.Close, "Temizle") }
            }
        },
        singleLine = true,
        shape = RoundedCornerShape(28.dp),
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { focus.clearFocus() })
    )
}

@Composable
fun SetupCard(onSetup: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        ElevatedCard(shape = RoundedCornerShape(28.dp)) {
            Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Klon alanını kur", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
                Text(
                    "Android'in resmi çalışma profili özelliği kullanılır. " +
                        "Seçtiğin uygulamalar bu ayrı alanda ikinci kopya olarak çalışır; " +
                        "verileri ana uygulamayla karışmaz.",
                    style = MaterialTheme.typography.bodyMedium
                )
                Button(onClick = onSetup, modifier = Modifier.fillMaxWidth()) { Text("Kurulumu başlat") }
            }
        }
    }
}

@Composable
fun AppList(
    apps: List<AppItem>,
    emptyText: String,
    modifier: Modifier = Modifier,
    onOpen: (AppItem) -> Unit,
    onRemove: (AppItem) -> Unit,
    isFav: (AppItem) -> Boolean = { false },
    onFav: ((AppItem) -> Unit)? = null,
    iconDp: Int = 48,
    selected: Set<String> = emptySet(),
    onSelect: ((AppItem) -> Unit)? = null
) {
    if (apps.isEmpty()) {
        Box(modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
            Text(emptyText, style = MaterialTheme.typography.bodyLarge)
        }
        return
    }
    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(apps, key = { it.pkg }) { app ->
            var menu by remember { mutableStateOf(false) }
            val isSel = app.pkg in selected
            val onTap by rememberUpdatedState<() -> Unit>({
                if (onSelect != null && selected.isNotEmpty()) onSelect(app) else onOpen(app)
            })
            val onLong by rememberUpdatedState<() -> Unit>({
                if (onSelect != null) onSelect(app) else menu = true
            })
            Box(Modifier.fillMaxWidth()) {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSel) MaterialTheme.colorScheme.primaryContainer
                        else MaterialTheme.colorScheme.surfaceContainer
                    ),
                    modifier = Modifier.fillMaxWidth().pointerInput(app.pkg) {
                        detectTapGestures(onLongPress = { onLong() }, onTap = { onTap() })
                    }
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(start = 12.dp, top = 12.dp, bottom = 12.dp, end = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Box(Modifier.size(iconDp.coerceIn(40, 56).dp), contentAlignment = Alignment.Center) {
                            Image(app.icon, null, Modifier.fillMaxSize())
                            if (isSel) Icon(Icons.Filled.Check, null, tint = MaterialTheme.colorScheme.primary)
                        }
                        Column(Modifier.weight(1f)) {
                            Text(app.label, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                            Text(
                                app.pkg, style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1
                            )
                        }
                        if (onFav != null) {
                            val fav = isFav(app)
                            IconButton(onClick = { onFav(app) }) {
                                Icon(
                                    if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                                    if (fav) "Favoriden çıkar" else "Favorilere ekle",
                                    tint = if (fav) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, "Menü") }
                    }
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Aç") }, onClick = { menu = false; onOpen(app) })
                    if (onFav != null) {
                        DropdownMenuItem(
                            text = { Text(if (isFav(app)) "Favorilerden çıkar" else "Favorilere ekle") },
                            onClick = { menu = false; onFav(app) }
                        )
                    }
                    if (app.removable) {
                        DropdownMenuItem(
                            text = { Text("Kaldır", color = MaterialTheme.colorScheme.error) },
                            onClick = { menu = false; onRemove(app) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
    ) {
        Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
            content()
        }
    }
}

@Composable
fun SwitchRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}


// ───────────────────────── Dosyalar ─────────────────────────

fun toast(ctx: Context, msg: String) =
    Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()

/** Köprü çalışmazsa profildeki uygulamayı açıp kendini onarmasını sağlar. */
private fun healProfile(ctx: Context, profile: UserHandle?) {
    if (profile != null) ProfileHelper.openProfileSide(ctx, profile)
    toast(ctx, "Klon alanı onarılıyor. Açılan ekrandan geri dönüp işlemi tekrar dene.")
}

@Composable
fun FilesScreen(
    profile: UserHandle?,
    tick: Int,
    settings: AppSettings,
    path: String,
    onPath: (String) -> Unit,
    apkOnly: Boolean,
    onApkOnly: (Boolean) -> Unit,
    refresh: () -> Unit,
    store: KlonStore? = null
) {
    val ctx = LocalContext.current
    val root = remember { Files.root() }
    val hasAccess = remember(tick) { Files.hasAccess(ctx) }
    var query by rememberSaveable { mutableStateOf("") }
    var apk by remember { mutableStateOf<File?>(null) }
    val scope = rememberCoroutineScope()
    // Seçili dosyalar (klon alanına gönderilecek); klasör değişince sıfırlanır
    var selected by remember(path) { mutableStateOf(setOf<String>()) }
    var reload by remember { mutableIntStateOf(0) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { refresh() }

    // Klondan al: sistem seçicisi (çalışma sekmesi dahil) → bulunulan klasöre kopyala
    val pickFromClone = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            val dest = File(path)
            scope.launch {
                val n = withContext(Dispatchers.IO) { Transfer.importUris(ctx, uris, dest) }
                toast(
                    ctx,
                    if (n == uris.size) "$n dosya bu klasöre alındı"
                    else "$n/${uris.size} dosya alınabildi"
                )
                reload++
            }
        }
    }

    val atRoot = path == root.absolutePath
    val goUp = { onPath(File(path).parentFile?.absolutePath ?: root.absolutePath); query = "" }
    BackHandler(enabled = hasAccess && !atRoot) { goUp() }
    BackHandler(enabled = hasAccess && selected.isNotEmpty()) { selected = emptySet() }

    val toggle: (File) -> Unit = { f ->
        val p = f.absolutePath
        selected = if (p in selected) selected - p else selected + p
    }
    val sendSelected: () -> Unit = {
        val files = selected.map { File(it) }.filter { it.isFile }
        if (profile == null) toast(ctx, "Önce Profil bölümünden klon alanını kur")
        else if (Transfer.sendToClone(ctx, files)) selected = emptySet()
        else healProfile(ctx, profile)
    }

    val entries by produceState(emptyList<FileEntry>(), path, apkOnly, settings.hidden, hasAccess, reload) {
        value = if (!hasAccess) emptyList()
        else withContext(Dispatchers.IO) { Files.list(File(path), apkOnly, settings.hidden) }
    }
    val list = remember(entries, query) {
        val q = query.trim()
        if (q.isEmpty()) entries else entries.filter { it.name.contains(q, ignoreCase = true) }
    }

    Column(Modifier.fillMaxSize()) {
        if (!hasAccess) {
            Column(
                Modifier.fillMaxSize().padding(24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                ElevatedCard(shape = RoundedCornerShape(28.dp)) {
                    Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Dosya erişimi gerekli", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
                        Text(
                            "Telefondaki dosyaları listelemek için tüm dosyalara erişim iznini vermen gerekir.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Button(
                            onClick = {
                                if (Build.VERSION.SDK_INT >= 30) {
                                    runCatching {
                                        ctx.startActivity(
                                            Intent(
                                                android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                                                Uri.parse("package:${ctx.packageName}")
                                            )
                                        )
                                    }.onFailure {
                                        runCatching {
                                            ctx.startActivity(Intent(android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                                        }
                                    }
                                } else {
                                    permLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("İzin ver") }
                    }
                }
            }
        } else {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(Files.quick()) { (name, f) ->
                    AssistChip(onClick = { onPath(f.absolutePath); query = "" }, label = { Text(name) })
                }
            }
            SearchField(query) { query = it }
            if (selected.isEmpty()) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        "Klona göndermek için dosyaya dokun veya uzun bas. Klondan almak için sağdaki düğmeyi kullan; seçicide çalışma sekmesini aç.",
                        modifier = Modifier.weight(1f),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedButton(onClick = {
                        if (profile == null) toast(ctx, "Önce Profil bölümünden klon alanını kur")
                        else pickFromClone.launch(arrayOf("*/*"))
                    }) { Text("Klondan al") }
                }
            } else {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "${selected.size} dosya seçili",
                        modifier = Modifier.weight(1f),
                        style = MaterialTheme.typography.titleSmall
                    )
                    TextButton(onClick = { selected = emptySet() }) { Text("Vazgeç") }
                    Button(onClick = sendSelected) { Text("Klona gönder") }
                }
            }
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (!atRoot) {
                    IconButton(onClick = { goUp() }) { Icon(Icons.Filled.ArrowBack, "Yukarı") }
                }
                Text(
                    "Dahili depolama" + path.removePrefix(root.absolutePath),
                    modifier = Modifier.weight(1f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                FilterChip(
                    selected = apkOnly,
                    onClick = { onApkOnly(!apkOnly) },
                    label = { Text("Sadece APK") }
                )
            }
            if (list.isEmpty()) {
                Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                    Text("Bu klasörde gösterilecek bir şey yok", style = MaterialTheme.typography.bodyLarge)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(list, key = { it.file.absolutePath }) { e ->
                        val longClick: (() -> Unit)? = if (e.isDir) null else ({ toggle(e.file) })
                        FileRow(e, selected = e.file.absolutePath in selected, onLong = longClick) {
                            when {
                                e.isDir -> { onPath(e.file.absolutePath); query = "" }
                                selected.isNotEmpty() -> toggle(e.file)
                                e.isApk -> apk = e.file
                                else -> toggle(e.file)
                            }
                        }
                    }
                }
            }
        }
    }

    apk?.let { f -> InstallDialog(f, profile, store) { apk = null } }
}

@Composable
fun FileRow(e: FileEntry, selected: Boolean = false, onLong: (() -> Unit)? = null, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val (bg, fg) = when {
        selected -> cs.primary to cs.onPrimary
        e.isDir -> cs.secondaryContainer to cs.onSecondaryContainer
        e.isApk -> cs.primaryContainer to cs.onPrimaryContainer
        else -> cs.surfaceContainerHighest to cs.onSurfaceVariant
    }
    val click by rememberUpdatedState(onClick)
    val long by rememberUpdatedState(onLong)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(if (selected) cs.primaryContainer else cs.surfaceContainer)
            .pointerInput(e.file.absolutePath) {
                detectTapGestures(onTap = { click() }, onLongPress = { long?.invoke() })
            }
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Box(
            Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(bg),
            contentAlignment = Alignment.Center
        ) {
            if (selected) Icon(Icons.Filled.Check, null, tint = fg)
            else if (e.isDir) FolderGlyph(fg, Modifier.size(26.dp))
            else Text(e.ext, color = fg, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
        Column(Modifier.weight(1f)) {
            Text(e.name, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                if (e.isDir) Files.formatDate(e.modified)
                else Files.formatSize(e.size) + " · " + Files.formatDate(e.modified),
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant
            )
        }
    }
}

@Composable
fun InstallDialog(file: File, profile: UserHandle?, store: KlonStore?, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val info by produceState<ApkInfo?>(null, file) {
        value = withContext(Dispatchers.IO) { Files.readApk(ctx, file) }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(28.dp),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                info?.icon?.let { Image(it, null, Modifier.size(52.dp).clip(RoundedCornerShape(14.dp))) }
                Text(info?.label ?: file.name, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(info?.pkg ?: "Paket bilgisi okunuyor…", style = MaterialTheme.typography.bodyMedium)
                Text(
                    listOfNotNull(
                        info?.version?.takeIf { it.isNotBlank() }?.let { "Sürüm $it" },
                        Files.formatSize(file.length())
                    ).joinToString(" · "),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    "Uygulama klon alanına kurulur. Android bir onay ekranı gösterebilir.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onDismiss()
                if (profile == null) toast(ctx, "Önce Profil bölümünden klon alanını kur")
                else if (!ProfileHelper.requestInstall(ctx, file)) healProfile(ctx, profile)
                else store?.log("install", info?.label ?: file.name, info?.pkg ?: "")
            }) { Text("Klon alanına kur") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Vazgeç") } }
    )
}

/** Klasör simgesi (ek ikon kütüphanesi gerektirmez). */
@Composable
fun FolderGlyph(color: Color, modifier: Modifier = Modifier.size(24.dp)) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val r = CornerRadius(w * 0.12f, w * 0.12f)
        drawRoundRect(color, topLeft = Offset(w * 0.04f, h * 0.16f), size = Size(w * 0.42f, h * 0.3f), cornerRadius = r)
        drawRoundRect(color, topLeft = Offset(w * 0.04f, h * 0.28f), size = Size(w * 0.92f, h * 0.56f), cornerRadius = r)
    }
}

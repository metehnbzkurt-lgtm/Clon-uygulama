package com.oguzhn.klonlayici

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.UserHandle
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.activity.compose.BackHandler
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val TRL = Locale("tr", "TR")

fun fmtTime(ms: Long): String = SimpleDateFormat("d MMM HH:mm", TRL).format(Date(ms))

// ───────────────────────── Menü ─────────────────────────

val SECTIONS = listOf(
    "Dashboard", "Uygulamalar", "Favoriler", "Geçmiş",
    "APK / Dosyalar", "Temalar", "Profil", "Ayarlar"
)

fun sectionIcon(i: Int): ImageVector = when (i) {
    0 -> Icons.Filled.Home
    1 -> Icons.Filled.Apps
    2 -> Icons.Filled.Favorite
    3 -> Icons.Filled.History
    4 -> Icons.Filled.FolderOpen
    5 -> Icons.Filled.Palette
    6 -> Icons.Filled.Person
    else -> Icons.Filled.Settings
}

// ───────────────────────── Tema renkleri ─────────────────────────

data class AccentDef(val name: String, val dark: Color, val onDark: Color, val light: Color)

val accentList = listOf(
    AccentDef("Mor", Color(0xFFB7A5FF), Color(0xFF24145C), Color(0xFF6250B5)),
    AccentDef("Mavi", Color(0xFF9CC9FF), Color(0xFF00315A), Color(0xFF1F5FA8)),
    AccentDef("Yeşil", Color(0xFF93D8A6), Color(0xFF00391B), Color(0xFF2E7D4A)),
    AccentDef("Turuncu", Color(0xFFFFB77C), Color(0xFF4A2800), Color(0xFFA85A00)),
    AccentDef("Pembe", Color(0xFFFFAFD0), Color(0xFF5B1138), Color(0xFFA23B6C)),
    AccentDef("Turkuaz", Color(0xFF7FD6D6), Color(0xFF003737), Color(0xFF00696B))
)

fun openAllFilesAccess(ctx: Context) {
    if (Build.VERSION.SDK_INT >= 30) {
        runCatching {
            ctx.startActivity(
                Intent(
                    android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:${ctx.packageName}")
                )
            )
        }.onFailure {
            runCatching {
                ctx.startActivity(Intent(android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        }
    }
}

// ───────────────────────── Dashboard ─────────────────────────

@Composable
private fun DashTitle(title: String, action: String, onAction: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            title, modifier = Modifier.weight(1f),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold
        )
        TextButton(onClick = onAction) { Text(action) }
    }
}

@Composable
fun DashboardScreen(
    loaded: Loaded,
    profileReady: Boolean,
    store: KlonStore,
    iconDp: Int,
    onOpen: (AppItem) -> Unit,
    goto: (Int) -> Unit,
    onRefresh: () -> Unit
) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 16.dp)) {
        if (!loaded.ready) LinearProgressIndicator(Modifier.fillMaxWidth())
        DashboardHeader(
            appCount = loaded.clones.size,
            ready = loaded.ready,
            profileReady = profileReady,
            onFiles = { goto(4) },
            onRefresh = onRefresh,
            favCount = loaded.clones.count { store.isFav(it.pkg) },
            listLabel = null
        )
        val favs = loaded.clones.filter { store.isFav(it.pkg) }.sortedBy { it.label.lowercase(TRL) }
        DashTitle("FAVORİLER", "Tümü") { goto(2) }
        if (favs.isEmpty()) {
            Text(
                "Henüz favori yok. Uygulamalar bölümünde kalp simgesine dokunarak ekleyebilirsin.",
                modifier = Modifier.padding(horizontal = 20.dp),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        } else {
            // Yana kaydırma yok: uygulama çekmecesi gibi alt alta satırlara dizilen ızgara
            BoxWithConstraints(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
                val cols = maxOf(3, (maxWidth / (iconDp + 32).dp).toInt())
                Column {
                    favs.chunked(cols).forEach { row ->
                        Row(Modifier.fillMaxWidth()) {
                            row.forEach { app ->
                                Column(
                                    Modifier.weight(1f).clip(RoundedCornerShape(16.dp))
                                        .clickable { onOpen(app) }
                                        .padding(vertical = 8.dp, horizontal = 2.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Image(app.icon, null, Modifier.size(iconDp.dp))
                                    Text(
                                        app.label, style = MaterialTheme.typography.labelSmall,
                                        textAlign = TextAlign.Center,
                                        maxLines = 1, overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                            // Son satırda eksik hücreleri boş bırak ki simgeler hizalı kalsın
                            repeat(cols - row.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                }
            }
        }
    }
}

// ───────────────────────── Uygulamalar / Favoriler ─────────────────────────

/** Izgara görünümü: simge boyutu ayarlardan gelir; uzun basış seçim (veya menü) açar. */
@Composable
fun AppGrid(
    apps: List<AppItem>,
    emptyText: String,
    modifier: Modifier = Modifier,
    iconDp: Int,
    onOpen: (AppItem) -> Unit,
    onRemove: (AppItem) -> Unit,
    isFav: (AppItem) -> Boolean,
    onFav: (AppItem) -> Unit,
    selected: Set<String> = emptySet(),
    onSelect: ((AppItem) -> Unit)? = null
) {
    if (apps.isEmpty()) {
        Box(modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
            Text(emptyText, style = MaterialTheme.typography.bodyLarge)
        }
        return
    }
    LazyVerticalGrid(
        columns = GridCells.Adaptive(minSize = (iconDp + 44).dp),
        modifier = modifier,
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(apps, key = { it.pkg }) { app ->
            var menu by remember { mutableStateOf(false) }
            val isSel = app.pkg in selected
            val onTap by rememberUpdatedState<() -> Unit>({
                if (onSelect != null && selected.isNotEmpty()) onSelect(app) else onOpen(app)
            })
            val onLong by rememberUpdatedState<() -> Unit>({
                if (onSelect != null) onSelect(app) else menu = true
            })
            Box(Modifier.fillMaxWidth()) {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSel) MaterialTheme.colorScheme.primaryContainer
                        else MaterialTheme.colorScheme.surfaceContainer
                    ),
                    modifier = Modifier.fillMaxWidth().pointerInput(app.pkg) {
                        detectTapGestures(onLongPress = { onLong() }, onTap = { onTap() })
                    }
                ) {
                    Box(Modifier.fillMaxWidth()) {
                        Column(
                            Modifier.fillMaxWidth().padding(start = 6.dp, end = 6.dp, top = 14.dp, bottom = 10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Image(app.icon, null, Modifier.size(iconDp.dp))
                            Text(
                                app.label, style = MaterialTheme.typography.labelMedium,
                                textAlign = TextAlign.Center, maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                        }
                        if (isSel) {
                            Icon(
                                Icons.Filled.Check, null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.align(Alignment.TopStart).padding(8.dp).size(20.dp)
                            )
                        }
                        val fav = isFav(app)
                        IconButton(
                            onClick = { onFav(app) },
                            modifier = Modifier.align(Alignment.TopEnd).size(34.dp)
                        ) {
                            Icon(
                                if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                                if (fav) "Favoriden çıkar" else "Favorilere ekle",
                                modifier = Modifier.size(18.dp),
                                tint = if (fav) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Aç") }, onClick = { menu = false; onOpen(app) })
                    DropdownMenuItem(
                        text = { Text(if (isFav(app)) "Favorilerden çıkar" else "Favorilere ekle") },
                        onClick = { menu = false; onFav(app) }
                    )
                    if (app.removable) {
                        DropdownMenuItem(
                            text = { Text("Kaldır", color = MaterialTheme.colorScheme.error) },
                            onClick = { menu = false; onRemove(app) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AppsScreen(
    loaded: Loaded,
    store: KlonStore,
    settings: AppSettings,
    query: String,
    onQuery: (String) -> Unit,
    sort: Int,
    onSort: (Int) -> Unit,
    onOpen: (AppItem) -> Unit,
    onRemove: (AppItem) -> Unit,
    onRemoveMany: (List<AppItem>) -> Unit
) {
    var listMode by rememberSaveable { mutableStateOf(settings.listView) }
    var selected by remember { mutableStateOf(setOf<String>()) }
    var confirm by remember { mutableStateOf(false) }

    val base = loaded.clones.filterQuery(query)
    val list = when (sort) {
        1 -> base.sortedWith(
            compareByDescending<AppItem> { store.openCount(it.pkg) }.thenBy { it.label.lowercase(TRL) }
        )
        2 -> base.sortedWith(
            compareByDescending<AppItem> { store.lastOpened(it.pkg) }.thenBy { it.label.lowercase(TRL) }
        )
        else -> base.sortedBy { it.label.lowercase(TRL) }
    }
    val toggle: (AppItem) -> Unit = { a ->
        selected = if (a.pkg in selected) selected - a.pkg else selected + a.pkg
    }
    val allSelected = list.isNotEmpty() && list.all { it.pkg in selected }
    BackHandler(enabled = selected.isNotEmpty()) { selected = emptySet() }

    val emptyText = when {
        !loaded.ready -> "Yükleniyor…"
        loaded.clones.isEmpty() -> "Henüz uygulama yok. Klon alanındaki Play Store'dan uygulama indirebilir ya da APK / Dosyalar bölümünden APK kurabilirsin."
        else -> "Sonuç bulunamadı"
    }

    Column(Modifier.fillMaxSize()) {
        if (!loaded.ready) LinearProgressIndicator(Modifier.fillMaxWidth())
        SearchField(query, onQuery)
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("A-Z", "En çok açılan", "Son açılan").forEachIndexed { i, n ->
                FilterChip(selected = sort == i, onClick = { onSort(i) }, label = { Text(n) })
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = allSelected,
                onCheckedChange = { c ->
                    val pkgs = list.map { it.pkg }
                    selected = if (c) selected + pkgs else selected - pkgs.toSet()
                }
            )
            Text(
                if (selected.isEmpty()) "Tümünü seç (${list.size})" else "Seçilen: ${selected.size}",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.weight(1f)
            )
            FilterChip(selected = !listMode, onClick = { listMode = false }, label = { Text("Izgara") })
            Spacer(Modifier.width(6.dp))
            FilterChip(selected = listMode, onClick = { listMode = true }, label = { Text("Liste") })
            Spacer(Modifier.width(8.dp))
        }
        if (listMode) {
            AppList(
                apps = list,
                emptyText = emptyText,
                modifier = Modifier.weight(1f),
                onOpen = onOpen,
                onRemove = onRemove,
                isFav = { store.isFav(it.pkg) },
                onFav = { store.toggleFav(it.pkg) },
                iconDp = settings.iconSize,
                selected = selected,
                onSelect = toggle
            )
        } else {
            AppGrid(
                apps = list,
                emptyText = emptyText,
                modifier = Modifier.weight(1f),
                iconDp = settings.iconSize,
                onOpen = onOpen,
                onRemove = onRemove,
                isFav = { store.isFav(it.pkg) },
                onFav = { store.toggleFav(it.pkg) },
                selected = selected,
                onSelect = toggle
            )
        }
        if (selected.isNotEmpty()) {
            Surface(
                color = MaterialTheme.colorScheme.primaryContainer,
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Row(
                    Modifier.padding(start = 16.dp, end = 8.dp, top = 6.dp, bottom = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("${selected.size} seçildi", modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold)
                    TextButton(onClick = { selected = emptySet() }) { Text("İptal") }
                    Button(
                        onClick = { confirm = true },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.error,
                            contentColor = MaterialTheme.colorScheme.onError
                        )
                    ) { Text("Kaldır") }
                }
            }
        }
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("${selected.size} uygulama kaldırılsın mı?") },
            text = { Text("Uygulamalar klon alanından kaldırılır. Android her uygulama için ayrı bir onay ekranı gösterir.") },
            confirmButton = {
                TextButton(onClick = {
                    val targets = loaded.clones.filter { it.pkg in selected }
                    confirm = false
                    selected = emptySet()
                    onRemoveMany(targets)
                }) { Text("Kaldır") }
            },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Vazgeç") } }
        )
    }
}

@Composable
fun FavoritesScreen(
    loaded: Loaded,
    store: KlonStore,
    iconDp: Int,
    onOpen: (AppItem) -> Unit,
    onRemove: (AppItem) -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        if (!loaded.ready) LinearProgressIndicator(Modifier.fillMaxWidth())
        val favs = loaded.clones.filter { store.isFav(it.pkg) }.sortedBy { it.label.lowercase(TRL) }
        AppGrid(
            apps = favs,
            emptyText = if (loaded.ready) "Henüz favori yok. Uygulamalar bölümünde kalp simgesine dokun." else "Yükleniyor…",
            modifier = Modifier.weight(1f),
            iconDp = iconDp,
            onOpen = onOpen,
            onRemove = onRemove,
            isFav = { store.isFav(it.pkg) },
            onFav = { store.toggleFav(it.pkg) }
        )
    }
}

// ───────────────────────── Geçmiş ─────────────────────────

fun typeLabel(t: String): String = when (t) {
    "open" -> "Açıldı"
    "install" -> "Kurulum istendi"
    "remove" -> "Kaldırma istendi"
    else -> t
}

@Composable
private fun typeColors(t: String): Pair<Color, Color> {
    val cs = MaterialTheme.colorScheme
    return when (t) {
        "install" -> cs.secondaryContainer to cs.onSecondaryContainer
        "remove" -> cs.errorContainer to cs.onErrorContainer
        else -> cs.primaryContainer to cs.onPrimaryContainer
    }
}

@Composable
fun HistoryRow(e: HistoryEntry) {
    val (bg, fg) = typeColors(e.type)
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
            .background(MaterialTheme.colorScheme.surfaceContainer)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Box(
            Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(bg),
            contentAlignment = Alignment.Center
        ) {
            Text(e.label.take(1).uppercase(TRL), color = fg, fontWeight = FontWeight.Bold)
        }
        Column(Modifier.weight(1f)) {
            Text(
                e.label.ifBlank { e.pkg }, style = MaterialTheme.typography.bodyLarge,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(
                typeLabel(e.type) + " · " + fmtTime(e.time),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun HistoryScreen(store: KlonStore) {
    var filter by rememberSaveable { mutableIntStateOf(0) }
    var confirm by remember { mutableStateOf(false) }
    val types = listOf("Tümü" to "", "Açılan" to "open", "Kurulan" to "install", "Kaldırılan" to "remove")
    val list = store.history.filter { filter == 0 || it.type == types[filter].second }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                Modifier.weight(1f).horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                types.forEachIndexed { i, t ->
                    FilterChip(selected = filter == i, onClick = { filter = i }, label = { Text(t.first) })
                }
            }
            if (store.history.isNotEmpty()) {
                TextButton(onClick = { confirm = true }) { Text("Temizle") }
            }
        }
        if (list.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                Text(
                    if (store.historyEnabled) "Henüz geçmiş yok" else "Geçmiş kaydı kapalı (Ayarlar bölümünden açabilirsin)",
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(list) { HistoryRow(it) }
            }
        }
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Geçmiş temizlensin mi?") },
            text = { Text("Açılan, kurulan ve kaldırılan uygulama kayıtları silinir. Klonların etkilenmez.") },
            confirmButton = {
                TextButton(onClick = { store.clearHistory(); confirm = false }) { Text("Temizle") }
            },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Vazgeç") } }
        )
    }
}

// ───────────────────────── Temalar ─────────────────────────

@Composable
fun ThemesScreen(s: AppSettings) {
    val dynamicAvailable = Build.VERSION.SDK_INT >= 31
    val accentActive = !(s.dynamic && dynamicAvailable)
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        SectionCard("Mod") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Sistem", "Açık", "Koyu").forEachIndexed { i, name ->
                    FilterChip(selected = s.theme == i, onClick = { s.updateTheme(i) }, label = { Text(name) })
                }
            }
            SwitchRow("AMOLED siyah", "Koyu temada saf siyah arka plan", s.amoled) { s.updateAmoled(it) }
        }
        SectionCard("Renkler") {
            if (dynamicAvailable) {
                SwitchRow("Dinamik renk", "Renkler duvar kağıdına uyar", s.dynamic) { s.updateDynamic(it) }
            }
            Text(
                if (accentActive) "Vurgu rengi" else "Aşağıdan bir renk seçersen dinamik renk kapanır",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            accentList.chunked(3).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { a ->
                        val idx = accentList.indexOf(a)
                        val selected = accentActive && s.accent == idx
                        Column(
                            Modifier.weight(1f).clip(RoundedCornerShape(16.dp))
                                .clickable { s.updateDynamic(false); s.updateAccent(idx) }
                                .padding(vertical = 8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                Modifier.size(48.dp).clip(CircleShape).background(a.dark)
                                    .then(
                                        if (selected) Modifier.border(3.dp, MaterialTheme.colorScheme.onSurface, CircleShape)
                                        else Modifier
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                if (selected) Icon(Icons.Filled.Check, null, tint = a.onDark)
                            }
                            Text(a.name, style = MaterialTheme.typography.labelMedium)
                        }
                    }
                    // Satır 3'ten az öğe içeriyorsa hizayı koru
                    repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
    }
}

// ───────────────────────── Profil ─────────────────────────

@Composable
private fun InfoRow(k: String, v: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(
            k, modifier = Modifier.weight(1f),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(v, style = MaterialTheme.typography.titleSmall)
    }
}

@Composable
fun ProfileScreen(
    profile: UserHandle?,
    loaded: Loaded,
    tick: Int,
    onSetup: () -> Unit
) {
    val ctx = LocalContext.current
    val hasAccess = remember(tick) { Files.hasAccess(ctx) }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        SectionCard("Klon alanı") {
            InfoRow("Durum", if (profile != null) "Hazır" else "Kurulmadı")
            if (profile != null) {
                InfoRow("Profil", profile.toString())
                InfoRow("Klon uygulama", loaded.clones.size.toString())
                InfoRow("Kaldırılabilir", loaded.clones.count { it.removable }.toString())
            }
            if (profile == null) {
                Text(
                    "Android'in resmi çalışma profili özelliği kullanılır. Kurulum sonrası seçtiğin uygulamalar ayrı bir alanda ikinci kopya olarak çalışır.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Button(onClick = onSetup, modifier = Modifier.fillMaxWidth()) { Text("Klon alanını kur") }
            } else {
                Button(
                    onClick = {
                        if (ProfileHelper.openProfileSide(ctx, profile)) {
                            toast(ctx, "Klon alanı onarılıyor. Açılan ekrandan geri dönebilirsin.")
                        } else {
                            toast(ctx, "Klon alanı şu an açılamadı")
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Klon alanını aç / onar") }
            }
        }
        SectionCard("İzinler") {
            InfoRow("Tüm dosyalara erişim", if (hasAccess) "Verildi" else "Gerekli")
            if (!hasAccess) {
                Text(
                    "APK / Dosyalar bölümünün çalışması için gerekir.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedButton(onClick = { openAllFilesAccess(ctx) }, modifier = Modifier.fillMaxWidth()) {
                    Text("İzin ver")
                }
            }
        }
        SectionCard("Gelişmiş") {
            Text(
                "Klon alanını tamamen silmek istersen telefon ayarlarında \"çalışma profili\" ara ve oradan kaldır. Bu işlem klon alanındaki tüm uygulamaları ve verilerini siler.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            OutlinedButton(
                onClick = { runCatching { ctx.startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)) } },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Telefon ayarlarını aç") }
        }
    }
}

// ───────────────────────── Ayarlar ─────────────────────────

@Composable
fun AppSettingsScreen(s: AppSettings, store: KlonStore) {
    val ctx = LocalContext.current
    val version = remember {
        runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: ""
    }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        SectionCard("Uygulama görünümü") {
            Text("Simge boyutu: ${s.iconSize} dp", style = MaterialTheme.typography.titleMedium)
            Slider(
                value = s.iconSize.toFloat(),
                onValueChange = { s.updateIconSize(it.toInt()) },
                valueRange = 40f..72f
            )
            Text("Varsayılan görünüm", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = !s.listView, onClick = { s.updateListView(false) }, label = { Text("Izgara") })
                FilterChip(selected = s.listView, onClick = { s.updateListView(true) }, label = { Text("Liste") })
            }
        }
        SectionCard("Dosyalar") {
            SwitchRow("Gizli dosyaları göster", "Adı nokta ile başlayan dosya ve klasörler", s.hidden) { s.updateHidden(it) }
        }
        SectionCard("Geçmiş ve favoriler") {
            SwitchRow(
                "Geçmişi kaydet", "Açılan, kurulan ve kaldırılan uygulamalar listelenir",
                store.historyEnabled
            ) { store.updateHistoryEnabled(it) }
            OutlinedButton(
                onClick = { store.clearHistory(); toast(ctx, "Geçmiş temizlendi") },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Geçmişi temizle") }
            OutlinedButton(
                onClick = { store.clearFavorites(); toast(ctx, "Favoriler sıfırlandı") },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Favorileri sıfırla") }
        }
        SectionCard("Görünüm") {
            Text(
                "Tema, AMOLED siyah ve vurgu renkleri Temalar bölümündedir.",
                style = MaterialTheme.typography.bodyMedium
            )
        }
        SectionCard("İpuçları") {
            Text(
                "Bir uygulamayı kaldırmak için Uygulamalar listesinde üzerine basılı tut. " +
                    "APK kurmak için APK / Dosyalar bölümünde APK'ya dokun; ilk kurulumda klon alanı için \"Bilinmeyen uygulamaları yükle\" izni istenebilir. " +
                    "Dosya aktarmak için APK / Dosyalar bölümünde dosyaya dokunup seç ve \"Klona gönder\"e bas (klon alanında İndirilenler/Klon Aktarım klasörüne kopyalanır); klondan almak için \"Klondan al\"ı kullan. " +
                    "Klon alanını onarmak veya silmek için Profil bölümüne bak.",
                style = MaterialTheme.typography.bodyMedium
            )
        }
        SectionCard("Hakkında") {
            Text("Klon Çalıştırıcı" + if (version.isNotBlank()) " $version" else "", style = MaterialTheme.typography.titleMedium)
            Text(
                "Android çalışma profili tabanlı klon yöneticisi.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

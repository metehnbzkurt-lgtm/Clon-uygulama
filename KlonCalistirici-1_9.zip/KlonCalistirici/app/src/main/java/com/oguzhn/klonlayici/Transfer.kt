package com.oguzhn.klonlayici

import android.content.ClipData
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import java.io.File
import java.util.Locale

/**
 * Ana (kişisel) taraf ile klon alanı arasında dosya kopyalama.
 * - Ana taraf → klon: sendToClone (profildeki ProfileActionActivity saveToDownloads ile kaydeder)
 * - Klon → ana taraf: sistem dosya seçicisinden gelen adresler importUris ile klasöre kopyalanır
 */
object Transfer {
    const val ACTION_RECEIVE_FILES = "com.oguzhn.klonlayici.RECEIVE_FILES"

    /** Klon alanında dosyaların kaydedileceği klasör (İndirilenler altında). */
    const val FOLDER = "Klon Aktarım"

    /** Ana taraftan: seçilen dosyaları klon alanına kaydetmesi için profile iletir. */
    fun sendToClone(ctx: Context, files: List<File>): Boolean = runCatching {
        if (files.isEmpty()) error("dosya yok")
        val uris = files.map { FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", it) }
        val i = Intent(ACTION_RECEIVE_FILES)
            .setDataAndType(uris[0], "*/*")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        val clip = ClipData.newRawUri("dosya", uris[0])
        uris.drop(1).forEach { clip.addItem(ClipData.Item(it)) }
        i.clipData = clip
        ctx.startActivity(i)
    }.isSuccess

    /** Gelen intent'teki tüm dosya adreslerini toplar. */
    fun urisOf(i: Intent): List<Uri> {
        val out = ArrayList<Uri>()
        val clip = i.clipData
        if (clip != null) {
            for (k in 0 until clip.itemCount) clip.getItemAt(k).uri?.let { out.add(it) }
        }
        if (out.isEmpty()) i.data?.let { out.add(it) }
        return out
    }

    fun displayName(ctx: Context, uri: Uri): String {
        val n = runCatching {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        }.getOrNull()
        val raw = n?.takeIf { it.isNotBlank() } ?: uri.lastPathSegment ?: "dosya"
        return File(raw).name.ifBlank { "dosya" }
    }

    private fun mimeOf(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }

    /** Aynı ada sahip dosya varsa "ad (1).uzantı" biçiminde boş bir ad üretir. */
    fun uniqueFile(dir: File, name: String): File {
        var f = File(dir, name)
        if (!f.exists()) return f
        val base = name.substringBeforeLast('.', name)
        val ext = name.substringAfterLast('.', "")
        var n = 1
        while (f.exists()) {
            f = File(dir, if (ext.isEmpty()) "$base ($n)" else "$base ($n).$ext")
            n++
        }
        return f
    }

    /**
     * Klon alanında (profil tarafında) çalışır: dosyaları İndirilenler/Klon Aktarım klasörüne yazar.
     * Arka planda çağrılmalı. Başarıyla kopyalanan dosya sayısını döndürür.
     */
    fun saveToDownloads(ctx: Context, uris: List<Uri>): Int {
        var ok = 0
        for (u in uris) {
            val name = displayName(ctx, u)
            val success = runCatching {
                val input = ctx.contentResolver.openInputStream(u) ?: error("dosya açılamadı")
                input.use { ins ->
                    if (Build.VERSION.SDK_INT >= 29) {
                        val resolver = ctx.contentResolver
                        val values = ContentValues().apply {
                            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                            put(MediaStore.MediaColumns.MIME_TYPE, mimeOf(name))
                            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/" + FOLDER)
                            put(MediaStore.MediaColumns.IS_PENDING, 1)
                        }
                        val target = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                            ?: error("kayıt oluşturulamadı")
                        try {
                            val out = resolver.openOutputStream(target) ?: error("dosya yazılamadı")
                            out.use { ins.copyTo(it) }
                            val ready = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                            resolver.update(target, ready, null, null)
                        } catch (e: Exception) {
                            runCatching { resolver.delete(target, null, null) }
                            throw e
                        }
                    } else {
                        // Eski Android: yazma izni olmadığından uygulamanın kendi indirilenler klasörü
                        val base = ctx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: ctx.filesDir
                        val dir = File(base, FOLDER).apply { mkdirs() }
                        val f = uniqueFile(dir, name)
                        try {
                            f.outputStream().use { ins.copyTo(it) }
                        } catch (e: Exception) {
                            runCatching { f.delete() }
                            throw e
                        }
                    }
                }
            }.isSuccess
            if (success) ok++
        }
        return ok
    }

    /**
     * Ana tarafta çalışır: sistem seçicisinden (klon alanı dahil) seçilen dosyaları verilen klasöre kopyalar.
     * Arka planda çağrılmalı. Başarıyla kopyalanan dosya sayısını döndürür.
     */
    fun importUris(ctx: Context, uris: List<Uri>, destDir: File): Int {
        var ok = 0
        runCatching { destDir.mkdirs() }
        for (u in uris) {
            val target = uniqueFile(destDir, displayName(ctx, u))
            val success = runCatching {
                val input = ctx.contentResolver.openInputStream(u) ?: error("dosya açılamadı")
                try {
                    input.use { ins -> target.outputStream().use { ins.copyTo(it) } }
                } catch (e: Exception) {
                    runCatching { target.delete() }
                    throw e
                }
            }.isSuccess
            if (success) ok++
        }
        return ok
    }
}

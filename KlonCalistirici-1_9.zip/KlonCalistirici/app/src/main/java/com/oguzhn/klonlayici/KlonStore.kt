package com.oguzhn.klonlayici

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

/** type: "open" | "install" | "remove" */
data class HistoryEntry(val type: String, val label: String, val pkg: String, val time: Long)

/**
 * Favoriler, geçmiş ve kullanım sayıları. Yalnızca bu uygulamanın kendi tercihlerinde saklanır;
 * çalışma profili altyapısına dokunmaz.
 */
class KlonStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("klon_store", Context.MODE_PRIVATE)

    var favorites by mutableStateOf(readFavs())
        private set
    var history by mutableStateOf(readHistory())
        private set
    var counts by mutableStateOf(readCounts())
        private set
    var historyEnabled by mutableStateOf(sp.getBoolean("history_on", true))
        private set

    fun isFav(pkg: String): Boolean = pkg in favorites

    fun toggleFav(pkg: String) {
        val n = if (pkg in favorites) favorites - pkg else favorites + pkg
        favorites = n
        sp.edit().putStringSet("fav", HashSet(n)).apply()
    }

    fun clearFavorites() {
        favorites = emptySet()
        sp.edit().remove("fav").apply()
    }

    fun updateHistoryEnabled(v: Boolean) {
        historyEnabled = v
        sp.edit().putBoolean("history_on", v).apply()
    }

    fun log(type: String, label: String, pkg: String) {
        if (!historyEnabled) return
        if (type == "open") {
            counts = counts + (pkg to ((counts[pkg] ?: 0) + 1))
            saveCounts()
        }
        history = (listOf(HistoryEntry(type, label, pkg, System.currentTimeMillis())) + history).take(MAX)
        saveHistory()
    }

    fun clearHistory() {
        history = emptyList()
        counts = emptyMap()
        sp.edit().remove("history").remove("counts").apply()
    }

    fun openCount(pkg: String): Int = counts[pkg] ?: 0

    fun lastOpened(pkg: String): Long =
        history.firstOrNull { it.type == "open" && it.pkg == pkg }?.time ?: 0L

    private fun readFavs(): Set<String> =
        sp.getStringSet("fav", null)?.toSet() ?: emptySet()

    private fun readHistory(): List<HistoryEntry> = runCatching {
        val arr = JSONArray(sp.getString("history", "[]"))
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            HistoryEntry(o.getString("t"), o.optString("l"), o.optString("p"), o.optLong("ts"))
        }
    }.getOrDefault(emptyList())

    private fun readCounts(): Map<String, Int> = runCatching {
        val o = JSONObject(sp.getString("counts", "{}"))
        o.keys().asSequence().associateWith { o.getInt(it) }
    }.getOrDefault(emptyMap())

    private fun saveHistory() {
        val arr = JSONArray()
        history.forEach {
            arr.put(JSONObject().put("t", it.type).put("l", it.label).put("p", it.pkg).put("ts", it.time))
        }
        sp.edit().putString("history", arr.toString()).apply()
    }

    private fun saveCounts() {
        val o = JSONObject()
        for ((k, v) in counts) o.put(k, v)
        sp.edit().putString("counts", o.toString()).apply()
    }

    companion object { private const val MAX = 200 }
}

# Klon Çalıştırıcı 1.6
Android çalışma profili tabanlı klon yöneticisi (Jetpack Compose + Material 3).

## 1.6 yenilikleri
- Premium koyu temada mor/viyole vurgu renkleri ve daha yumuşak yüzey tonları.
- Yenilenen üst başlık ve hızlı yenileme eylemi.
- Ana ekranda çalışma alanı durumu, klon sayısı ve APK/Dosyalar kısayolu.
- Klon listesinde alfabetik sıralama.
- Mevcut çalışma profili, uygulama açma/kaldırma ve APK yükleme akışı korunmuştur.

## Derleme
GitHub Actions sekmesinden `APK Derle` iş akışını `Run workflow` ile başlatın. APK, işlem tamamlandığında `KlonCalistirici-release` artifact'i altında bulunur.

## Notlar
- Uygulama Android'in yönetilen çalışma profili mekanizmasını kullanır; cihaz ve üretici politikalarına bağlı sınırlamalar olabilir.
- Mevcut kurulu uygulamanın üzerine güncelleme yapabilmek için imza anahtarını koruyun. Keystore dosyasını ve parolasını herkese açık depolarda paylaşmayın; güvenli GitHub Actions Secrets kullanımına geçiş planlayın.
